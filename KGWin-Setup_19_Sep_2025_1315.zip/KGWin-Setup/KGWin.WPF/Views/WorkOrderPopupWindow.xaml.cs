using System.Windows;
using System.Windows.Input;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for WorkOrderPopupWindow.xaml
    /// </summary>
    public partial class WorkOrderPopupWindow : Window
    {
        public WorkOrderPopupWindow()
        {
            InitializeComponent();
        }

        public WorkOrderPopupWindow(string workOrderUrl) : this()
        {
            // Set the DataContext with the URL
            DataContext = new { WorkOrderUrl = workOrderUrl };
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Backdrop_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Close the popup when clicking on the backdrop
            Close();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
            base.OnKeyDown(e);
        }
    }
}

