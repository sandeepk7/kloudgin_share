using System;
using System.Windows;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for MapPopupWindow.xaml
    /// </summary>
    public partial class MapPopupWindow : Window
    {
        private Map? _map;
        private GraphicsOverlay? _markersOverlay;
        private MapPoint? _targetLocation;

        public MapPopupWindow()
        {
            InitializeComponent();
            InitializeMap();
        }

        public MapPopupWindow(string title, string type, double longitude, double latitude) : this()
        {
            Title = title;
            DataContext = new { PopupTitle = title, PopupType = type };
            _targetLocation = new MapPoint(longitude, latitude, SpatialReferences.Wgs84);
        }

        private async void InitializeMap()
        {
            try
            {
                LoadingOverlay.Visibility = Visibility.Visible;

                // Create a new map with a topographic basemap
                _map = new Map(BasemapStyle.ArcGISTopographic);
                
                // Create graphics overlay for markers
                _markersOverlay = new GraphicsOverlay();
                if (MapView != null)
                {
                    var mapView = MapView;
                    mapView.GraphicsOverlays.Add(_markersOverlay);
                    mapView.Map = _map;
                }

                // Wait for the map to load
                await _map.LoadAsync();

                // If we have a target location, navigate to it and add a marker
                if (_targetLocation != null)
                {
                    // Convert to Web Mercator for display
                    var webMercatorPoint = (MapPoint)GeometryEngine.Project(_targetLocation, SpatialReferences.WebMercator);
                    
                    // Navigate to the location
                    if (MapView != null)
                    {
                        await MapView.SetViewpointAsync(new Viewpoint(webMercatorPoint, 10000));
                    }

                    // Add a marker at the location
                    var markerSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle.Circle, System.Drawing.Color.Red, 12);
                    var graphic = new Graphic(webMercatorPoint, markerSymbol);
                    _markersOverlay!.Graphics.Add(graphic);
                }
                else
                {
                    // Default view (Los Angeles area)
                    var defaultPoint = new MapPoint(-118.2437, 34.0522, SpatialReferences.Wgs84);
                    var webMercatorPoint = (MapPoint)GeometryEngine.Project(defaultPoint, SpatialReferences.WebMercator);
                    if (MapView != null)
                    {
                        await MapView.SetViewpointAsync(new Viewpoint(webMercatorPoint, 100000));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error initializing map: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                LoadingOverlay.Visibility = Visibility.Collapsed;
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MapView_GeoViewTapped(object sender, GeoViewInputEventArgs e)
        {
            // Handle map tap events if needed
            var tappedLocation = e.Position;
            // You can add custom logic here for map interactions
        }

        private async void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            if (MapView != null)
            {
                await MapView.SetViewpointScaleAsync(MapView.MapScale * 0.5);
            }
        }

        private async void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            if (MapView != null)
            {
                await MapView.SetViewpointScaleAsync(MapView.MapScale * 2.0);
            }
        }

        private async void Reset_Click(object sender, RoutedEventArgs e)
        {
            if (MapView != null && _targetLocation != null)
            {
                var webMercatorPoint = (MapPoint)GeometryEngine.Project(_targetLocation, SpatialReferences.WebMercator);
                await MapView.SetViewpointAsync(new Viewpoint(webMercatorPoint, 10000));
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            // Clean up resources
            if (MapView != null)
            {
                MapView.Map = null;
            }
            base.OnClosed(e);
        }
    }
}
