using System;
using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Security;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KGWin.WPF.Services
{
    public class EsriMapService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;

        public EsriMapService(IConfiguration configuration, ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public void Initialize()
        {
            try
            {
                var apiKey = _configuration["ArcGIS:ApiKey"];
                var enableTimestampOffset = _configuration.GetValue<bool>("ArcGIS:EnableTimestampOffsetSupport");
                var useDefaultChallengeHandler = _configuration.GetValue<bool>("ArcGIS:UseDefaultChallengeHandler");

                ArcGISRuntimeEnvironment.Initialize(config => config
                    .UseApiKey(apiKey)
                    .ConfigureAuthentication(auth =>
                    {
                        if (useDefaultChallengeHandler)
                        {
                            auth.UseDefaultChallengeHandler();
                        }
                    })
                );

                if (enableTimestampOffset)
                {
                    ArcGISRuntimeEnvironment.EnableTimestampOffsetSupport = true;
                }

                _logger.LogInformation("EsriMapService: ArcGIS initialized");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "EsriMapService: ArcGIS initialization failed");
                throw;
            }
        }
    }
}


