using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using KGWin.WPF.ViewModels;
using KGWin.WPF.Views;

namespace KGWin.WPF.Services
{
    public class ModalPopupService
    {
        private static ModalPopupService? _instance;
        private static readonly object _lock = new object();
        private ModalPopupUserControl? _modalOverlay;

        public static ModalPopupService Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                        {
                            _instance = new ModalPopupService();
                        }
                    }
                }
                return _instance;
            }
        }

        private ModalPopupService() { }

        public void SetModalOverlay(ModalPopupUserControl modalOverlay)
        {
            _modalOverlay = modalOverlay;
        }

        // Convenience methods for common popup types using overlay
        public void ShowInfoPopup(string title, string message)
        {
            var config = new ModalPopupConfig
            {
                ShowFooter = true,
                ShowOkButton = true,
                Width = 400,
                Height = 200,
                ResizeMode = ResizeMode.NoResize
            };

            var textBlock = new System.Windows.Controls.TextBlock
            {
                Text = message,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(20),
                VerticalAlignment = VerticalAlignment.Center
            };

            ShowOverlay(title, textBlock, config);
        }

        public void ShowConfirmationPopup(string title, string message, Action? onOk = null, Action? onCancel = null)
        {
            var config = new ModalPopupConfig
            {
                ShowFooter = true,
                ShowOkButton = true,
                ShowCancelButton = true,
                Width = 400,
                Height = 200,
                ResizeMode = ResizeMode.NoResize
            };

            var textBlock = new System.Windows.Controls.TextBlock
            {
                Text = message,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(20),
                VerticalAlignment = VerticalAlignment.Center
            };

            var viewModel = new ModalPopupViewModel(title, textBlock, config)
            {
                OnOk = onOk,
                OnCancel = onCancel
            };

            ShowOverlay(viewModel);
        }

        public void ShowCustomViewPopup(string title, object view, ModalPopupConfig? config = null)
        {
            ShowOverlay(title, view, config);
        }

        // New methods for UserControl-based modal overlay
        public void ShowOverlay(string title, object content, ModalPopupConfig? config = null)
        {
            if (_modalOverlay == null)
            {
                throw new InvalidOperationException("Modal overlay not set. Call SetModalOverlay() first.");
            }

            var viewModel = new ModalPopupViewModel(title, content, config);
            _modalOverlay.DataContext = viewModel;
            _modalOverlay.Show();
        }

        public void ShowOverlay(ModalPopupViewModel viewModel)
        {
            if (_modalOverlay == null)
            {
                throw new InvalidOperationException("Modal overlay not set. Call SetModalOverlay() first.");
            }

            _modalOverlay.DataContext = viewModel;
            _modalOverlay.Show();
        }

        public void HideOverlay()
        {
            _modalOverlay?.Hide();
        }

        public bool IsOverlayVisible => _modalOverlay?.IsVisible ?? false;
    }
}
