using System.Windows.Input;
using KGWin.WPF.ViewModels.Base;
using Microsoft.Extensions.Configuration;

namespace KGWin.WPF.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly HomeViewModel _homeViewModel;
        private readonly IConfiguration? _configuration;

        public MainViewModel(IConfiguration? configuration = null)
        {
            _configuration = configuration;
            _homeViewModel = new HomeViewModel();
            InitializeCommands();
            // Set default page to Web
            NavigateToWeb();
        }

        private string _currentPage = "Web";
        public string CurrentPage 
        { 
            get => _currentPage; 
            set => SetProperty(ref _currentPage, value); 
        }

        private string _currentTitle = "CefSharp Web";
        public string CurrentTitle
        {
            get => _currentTitle;
            set => SetProperty(ref _currentTitle, value);
        }



        public HomeViewModel HomeViewModel => _homeViewModel;

        private MapViewModel? _mapViewModel;
        public MapViewModel? MapViewModel 
        { 
            get 
            {
                if (_mapViewModel == null)
                {
                    _mapViewModel = new MapViewModel();
                }
                return _mapViewModel;
            }
            set => SetProperty(ref _mapViewModel, value);
        }

        private CSWebViewModel? _webViewModel;
        public CSWebViewModel? WebViewModel 
        { 
            get 
            {
                if (_webViewModel == null)
                {
                    _webViewModel = new CSWebViewModel(_configuration);
                }
                return _webViewModel;
            }
            set => SetProperty(ref _webViewModel, value);
        }

        private CommunicationViewModel? _communicationViewModel;
        public CommunicationViewModel? CommunicationViewModel 
        { 
            get 
            {
                if (_communicationViewModel == null)
                {
                    _communicationViewModel = new CommunicationViewModel();
                    _communicationViewModel.MainViewModel = this;
                }
                return _communicationViewModel;
            }
            set
            {
                SetProperty(ref _communicationViewModel, value);
                if (_communicationViewModel != null)
                {
                    _communicationViewModel.MainViewModel = this;
                }
            }
        }

        private NapervilleViewModel? _napervilleViewModel;
        public NapervilleViewModel? NapervilleViewModel 
        { 
            get 
            {
                if (_napervilleViewModel == null)
                {
                    _napervilleViewModel = new NapervilleViewModel();
                }
                return _napervilleViewModel;
            }
            set => SetProperty(ref _napervilleViewModel, value);
        }



        // Commands
        public ICommand NavigateToHomeCommand { get; private set; } = null!;
        public ICommand NavigateToMapCommand { get; private set; } = null!;
        public ICommand NavigateToWebCommand { get; private set; } = null!;
        public ICommand NavigateToNapervilleCommand { get; private set; } = null!;

        private void InitializeCommands()
        {
            NavigateToHomeCommand = new RelayCommand(NavigateToHome);
            NavigateToMapCommand = new RelayCommand(NavigateToMap);
            NavigateToWebCommand = new RelayCommand(NavigateToWeb);
            NavigateToNapervilleCommand = new RelayCommand(NavigateToNaperville);
        }

        private void NavigateToHome()
        {
            System.Diagnostics.Debug.WriteLine("NavigateToHome called");
            CurrentPage = "Home";
            UpdateTitle();
        }

        private void NavigateToMap()
        {
            System.Diagnostics.Debug.WriteLine("NavigateToMap called");
            CurrentPage = "Map";
            UpdateTitle();
        }

        private void NavigateToWeb()
        {
            System.Diagnostics.Debug.WriteLine("NavigateToWeb called");
            
            // Get the URL from HomeViewModel and set it in CSWebViewModel
            var url = _homeViewModel.UserInput;
            
            // If no URL is provided or it's empty, use the configured default
            if (string.IsNullOrWhiteSpace(url))
            {
                url = _configuration?["Browser:Address"] ?? "http://localhost:4200";
            }
            else
            {
                // Ensure URL has protocol
                if (!url.StartsWith("http://") && !url.StartsWith("https://"))
                {
                    url = "https://" + url;
                }
            }
            
            // WebViewModel will be lazy-loaded when accessed
            WebViewModel!.BrowserAddress = url;
            
            CurrentPage = "Web";
            UpdateTitle();
        }

        private void NavigateToNaperville()
        {
            System.Diagnostics.Debug.WriteLine("NavigateToNaperville called");
            CurrentPage = "Naperville";
            UpdateTitle();
        }



        // Method to send message from Communication page to Angular
        public void SendMessageToAngular(string messageText)
        {
            // If we're on the Web page, send the message to Angular
            if (CurrentPage == "Web" && _webViewModel != null)
            {
                // The message will be sent via the CSWebView's CommunicationService
                System.Diagnostics.Debug.WriteLine($"MainViewModel: Sending message to Angular: {messageText}");
                
                // We need to access the CSWebView to send the message
                // This will be handled by the CSWebView when it's active
            }
        }

        // Reference to CSWebView for communication
        public Views.CSWebView? CSWebView { get; set; }

        // Method to send message to Angular via CSWebView
        public void SendMessageToAngularViaWebView(string messageText)
        {
            if (CSWebView != null)
            {
                CSWebView.SendMessageToAngular(messageText);
            }
        }

        private void UpdateTitle()
        {
            switch (CurrentPage)
            {
                case "Home":
                    CurrentTitle = "Home";
                    break;
                case "Map":
                    CurrentTitle = "ESRI .NET Map";
                    break;
                case "Web":
                    CurrentTitle = "CefSharp Web";
                    break;
                case "Naperville":
                    CurrentTitle = "Naperville";
                    break;

                default:
                    CurrentTitle = CurrentPage;
                    break;
            }
        }
    }
}

