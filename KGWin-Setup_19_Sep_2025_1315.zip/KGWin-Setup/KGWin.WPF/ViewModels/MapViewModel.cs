using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Esri.ArcGISRuntime.Data;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Location;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Security;
using Esri.ArcGISRuntime.Symbology;
using Esri.ArcGISRuntime.Tasks;
using Esri.ArcGISRuntime.UI;
using Esri.ArcGISRuntime.UI.Controls;
using KGWin.WPF.ViewModels.Base;

namespace KGWin.WPF.ViewModels
{
    /// <summary>
    /// Provides map data to an application
    /// </summary>
    public class MapViewModel : ViewModelBase
    {
        private Map _liveWorldMap;
        private Map _offlineMap;
        private string _activeTab = "LIVE MAP";
        private double _latitude = 4027494.2069;
        private double _longitude = -13162806.2096;
        private int _zoomLevel = 10;
        private bool _showAssetLayer = false;
        private bool _showAssetDetails = false;
        private bool _liveBasemapIsImagery = false;
        private string _offlineDataStatus = "No offline data loaded";

        // Popup properties
        private bool _isPopupVisible = false;
        private string _popupTitle = "";
        private string _popupType = "";
        private string _popupId = "";
        private string _popupColor = "";
        private string _popupLongitude = "";
        private string _popupLatitude = "";
        private string _popupDescription = "";
        private string _popupStatus = "";
        private string _popupNotes = "";

        // Graphics overlays for assets and markers
        public GraphicsOverlay AssetsOverlay { get; } = new GraphicsOverlay();
        public GraphicsOverlay MarkersOverlay { get; } = new GraphicsOverlay();

        public MapViewModel()
        {
            // Initialize Live World Map
            _liveWorldMap = new Map(SpatialReferences.WebMercator)
            {
                Basemap = new Basemap(BasemapStyle.ArcGISStreets),
                InitialViewpoint = new Viewpoint(
                    new MapPoint(-118.2437, 34.0522, SpatialReferences.Wgs84), // Los Angeles coordinates
                    1000000 // Zoom level to show LA area
                )
            };

            // Removed LA City Map

            // Initialize Offline Map
            _offlineMap = new Map(SpatialReferences.WebMercator)
            {
                Basemap = new Basemap(BasemapStyle.ArcGISImagery),
                InitialViewpoint = new Viewpoint(
                    new MapPoint(-118.2437, 34.0522, SpatialReferences.Wgs84), // Los Angeles coordinates
                    1000000 // Zoom level to show LA area
                )
            };

            InitializeCommands();
        }

        /// <summary>
        /// Gets the Live World Map
        /// </summary>
        public Map LiveWorldMap
        {
            get => _liveWorldMap;
            set => SetProperty(ref _liveWorldMap, value);
        }

        // Removed LA City Map property

        /// <summary>
        /// Gets the Offline Map
        /// </summary>
        public Map OfflineMap
        {
            get => _offlineMap;
            set => SetProperty(ref _offlineMap, value);
        }

        /// <summary>
        /// Gets the current map based on active tab
        /// </summary>
        public Map Map
        {
            get
            {
                return ActiveTab switch
                {
                    "LIVE MAP" => _liveWorldMap,
                    // Removed LA City option
                    "OFFLINE MAP" => _offlineMap,
                    _ => _liveWorldMap
                };
            }
        }

        /// <summary>
        /// Gets or sets the active tab
        /// </summary>
        public string ActiveTab
        {
            get => _activeTab;
            set => SetProperty(ref _activeTab, value);
        }

        /// <summary>
        /// Gets or sets the current latitude
        /// </summary>
        public double Latitude
        {
            get => _latitude;
            set => SetProperty(ref _latitude, value);
        }

        /// <summary>
        /// Gets or sets the current longitude
        /// </summary>
        public double Longitude
        {
            get => _longitude;
            set => SetProperty(ref _longitude, value);
        }

        /// <summary>
        /// Gets or sets the current zoom level
        /// </summary>
        public int ZoomLevel
        {
            get => _zoomLevel;
            set => SetProperty(ref _zoomLevel, value);
        }

        /// <summary>
        /// Gets or sets whether to show asset layer
        /// </summary>
        public bool ShowAssetLayer
        {
            get => _showAssetLayer;
            set => SetProperty(ref _showAssetLayer, value);
        }

        /// <summary>
        /// Gets or sets whether to show asset details
        /// </summary>
        public bool ShowAssetDetails
        {
            get => _showAssetDetails;
            set => SetProperty(ref _showAssetDetails, value);
        }

        /// <summary>
        /// True when Live map is showing Imagery; false when showing Streets
        /// </summary>
        public bool LiveBasemapIsImagery
        {
            get => _liveBasemapIsImagery;
            set
            {
                if (SetProperty(ref _liveBasemapIsImagery, value))
                {
                    OnPropertyChanged(nameof(LiveBasemapToggleLabel));
                }
            }
        }

        /// <summary>
        /// Label for the basemap toggle button
        /// </summary>
        public string LiveBasemapToggleLabel => LiveBasemapIsImagery ? "Switch to Streets" : "Switch to Imagery";

        /// <summary>
        /// Gets or sets the offline data status
        /// </summary>
        public string OfflineDataStatus
        {
            get => _offlineDataStatus;
            set => SetProperty(ref _offlineDataStatus, value);
        }

        // Popup Properties
        public bool IsPopupVisible
        {
            get => _isPopupVisible;
            set => SetProperty(ref _isPopupVisible, value);
        }

        public string PopupTitle
        {
            get => _popupTitle;
            set => SetProperty(ref _popupTitle, value);
        }

        public string PopupType
        {
            get => _popupType;
            set => SetProperty(ref _popupType, value);
        }

        public string PopupId
        {
            get => _popupId;
            set => SetProperty(ref _popupId, value);
        }

        public string PopupColor
        {
            get => _popupColor;
            set => SetProperty(ref _popupColor, value);
        }

        public string PopupLongitude
        {
            get => _popupLongitude;
            set => SetProperty(ref _popupLongitude, value);
        }

        public string PopupLatitude
        {
            get => _popupLatitude;
            set => SetProperty(ref _popupLatitude, value);
        }

        public string PopupDescription
        {
            get => _popupDescription;
            set => SetProperty(ref _popupDescription, value);
        }

        public string PopupStatus
        {
            get => _popupStatus;
            set => SetProperty(ref _popupStatus, value);
        }

        public string PopupNotes
        {
            get => _popupNotes;
            set => SetProperty(ref _popupNotes, value);
        }

        // Commands
        public ICommand ActivateLiveMapCommand { get; private set; } = null!;
        // Removed ActivateLACityCommand
        public ICommand ActivateOfflineMapCommand { get; private set; } = null!;
        public ICommand ShowAssetLayerCommand { get; private set; } = null!;
        public ICommand ShowAssetDetailsCommand { get; private set; } = null!;
        public ICommand RotateLeftCommand { get; private set; } = null!;
        public ICommand RotateRightCommand { get; private set; } = null!;
        public ICommand ResetCommand { get; private set; } = null!;
        public ICommand ToggleBasemapCommand { get; private set; } = null!;
        public ICommand ShowAssetsCommand { get; private set; } = null!;
        public ICommand ShowMarkersCommand { get; private set; } = null!;
        public ICommand ClearMapCommand { get; private set; } = null!;
        public ICommand LoadVtpkCommand { get; private set; } = null!;
        public ICommand LoadMmpkCommand { get; private set; } = null!;
        public ICommand ClosePopupCommand { get; private set; } = null!;
        public ICommand SavePopupCommand { get; private set; } = null!;
        public ICommand OpenWebMapCommand { get; private set; } = null!;

        // Method to handle graphic clicks
        public void HandleGraphicClick(Graphic graphic)
        {
            if (graphic?.Attributes != null)
            {
                var type = graphic.Attributes.ContainsKey("type") ? graphic.Attributes["type"]?.ToString() : "unknown";
                var id = graphic.Attributes.ContainsKey("id") ? graphic.Attributes["id"]?.ToString() : "unknown";
                var title = graphic.Attributes.ContainsKey("title") ? graphic.Attributes["title"]?.ToString() : "Unknown";
                var color = graphic.Attributes.ContainsKey("color") ? graphic.Attributes["color"]?.ToString() : "Unknown";
                var longitude = graphic.Attributes.ContainsKey("longitude") ? graphic.Attributes["longitude"]?.ToString() : "Unknown";
                var latitude = graphic.Attributes.ContainsKey("latitude") ? graphic.Attributes["latitude"]?.ToString() : "Unknown";

                // Show popup instead of MessageBox
                ShowPopup(type ?? "unknown", id ?? "unknown", title ?? "Unknown", color ?? "Unknown", longitude ?? "Unknown", latitude ?? "Unknown");
            }
        }

        public void ShowPopup(string type, string id, string title, string color, string longitude, string latitude)
        {
            PopupType = type?.ToUpper() ?? "UNKNOWN";
            PopupId = id ?? "Unknown";
            PopupTitle = title ?? "Unknown";
            PopupColor = color ?? "Unknown";
            PopupLongitude = longitude ?? "Unknown";
            PopupLatitude = latitude ?? "Unknown";
            PopupDescription = $"This is a {type} located at coordinates {longitude}, {latitude}";
            PopupStatus = "Active";
            PopupNotes = "";
            IsPopupVisible = true;
        }

        private void ClosePopup()
        {
            IsPopupVisible = false;
        }

        private void SavePopup()
        {
            // Here you would typically save the data to a database or file
            
            // Show success message
            System.Windows.MessageBox.Show("Data saved successfully!", "Success", 
                System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
            
            ClosePopup();
        }


        private void OpenWebMap()
        {
            try
            {
                // Get the current popup data to pass to the work order page
                var popupData = new
                {
                    id = PopupId,
                    type = PopupType,
                    title = PopupTitle,
                    color = PopupColor,
                    longitude = PopupLongitude,
                    latitude = PopupLatitude,
                    description = PopupDescription,
                    status = PopupStatus,
                    notes = PopupNotes
                };

                // Convert to JSON
                var jsonData = System.Text.Json.JsonSerializer.Serialize(popupData);
                
                // URL encode the data
                var encodedData = System.Web.HttpUtility.UrlEncode(jsonData);
                
                // Construct the work order URL with the popup data
                var workOrderUrl = $"http://localhost:4200/work-order?popupData={encodedData}";
                
                // Open the work order page in a WPF popup with Chromium WebView
                var webMapPopup = new Views.WebMapPopupView(workOrderUrl);
                webMapPopup.Show();
                
                System.Diagnostics.Debug.WriteLine($"Opening work order page with URL: {workOrderUrl}");
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error opening work order page: {ex.Message}");
                System.Windows.MessageBox.Show($"Error opening work order page: {ex.Message}", "Error", 
                    System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }
        }

        private void InitializeCommands()
        {
            ActivateLiveMapCommand = new RelayCommand(ActivateLiveMap);
            // Removed ActivateLACityCommand assignment
            ActivateOfflineMapCommand = new RelayCommand(ActivateOfflineMap);
            ShowAssetLayerCommand = new RelayCommand(ToggleAssetLayer);
            ShowAssetDetailsCommand = new RelayCommand(ToggleAssetDetails);
            RotateLeftCommand = new RelayCommand(RotateLeft);
            RotateRightCommand = new RelayCommand(RotateRight);
            ResetCommand = new RelayCommand(Reset);
            ToggleBasemapCommand = new RelayCommand(ToggleBasemap);
            ShowAssetsCommand = new RelayCommand(ShowAssets);
            ShowMarkersCommand = new RelayCommand(ShowMarkers);
            ClearMapCommand = new RelayCommand(ClearMap);
            LoadVtpkCommand = new RelayCommand(LoadVtpk);
            LoadMmpkCommand = new RelayCommand(LoadMmpk);
            ClosePopupCommand = new RelayCommand(ClosePopup);
            SavePopupCommand = new RelayCommand(SavePopup);
            OpenWebMapCommand = new RelayCommand(OpenWebMap);
        }

        private void ActivateLiveMap()
        {
            ActiveTab = "LIVE MAP";
            // Switch to live map basemap
            LiveWorldMap.Basemap = new Basemap(BasemapStyle.ArcGISStreets);
            LiveBasemapIsImagery = false;
        }

        private void ActivateOfflineMap()
        {
            ActiveTab = "OFFLINE MAP";
            // Switch to offline map basemap (could be a local tile package)
            OfflineMap.Basemap = new Basemap(BasemapStyle.ArcGISImagery);
        }

        private void ToggleBasemap()
        {
            // Only affects Live map
            LiveBasemapIsImagery = !LiveBasemapIsImagery;
            LiveWorldMap.Basemap = new Basemap(
                LiveBasemapIsImagery ? BasemapStyle.ArcGISImagery : BasemapStyle.ArcGISStreets);
        }

        private readonly Random _random = new Random();

        private void ShowAssets()
        {
            // Clear previous assets; add 10 random green pin graphics
            AssetsOverlay.Graphics.Clear();
            for (int i = 0; i < 10; i++)
            {
                var point = GetRandomPointNearLA();
                var attrLonLat = (MapPoint)GeometryEngine.Project(point, SpatialReferences.Wgs84);
                var symbol = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle.Triangle, System.Drawing.Color.FromArgb(0, 158, 115), 20);
                var graphic = new Graphic(point, symbol)
                {
                    Attributes = { 
                        ["type"] = "asset", 
                        ["id"] = $"asset_{i:D3}",
                        ["title"] = $"Asset {i + 1}",
                        ["color"] = "#009E73",
                        ["longitude"] = attrLonLat.X,
                        ["latitude"] = attrLonLat.Y
                    }
                };
                AssetsOverlay.Graphics.Add(graphic);
            }
        }

        private void ShowMarkers()
        {
            // Clear previous markers; add 10 random blue pin graphics
            MarkersOverlay.Graphics.Clear();
            for (int i = 0; i < 10; i++)
            {
                var point = GetRandomPointNearLA();
                var attrLonLat = (MapPoint)GeometryEngine.Project(point, SpatialReferences.Wgs84);
                var symbol = new SimpleMarkerSymbol(SimpleMarkerSymbolStyle.Triangle, System.Drawing.Color.FromArgb(37, 99, 235), 20);
                var graphic = new Graphic(point, symbol)
                {
                    Attributes = { 
                        ["type"] = "marker", 
                        ["id"] = $"marker_{i:D3}",
                        ["title"] = $"Marker {i + 1}",
                        ["color"] = "#2563EB",
                        ["longitude"] = attrLonLat.X,
                        ["latitude"] = attrLonLat.Y
                    }
                };
                MarkersOverlay.Graphics.Add(graphic);
            }
        }

        private void ClearMap()
        {
            AssetsOverlay.Graphics.Clear();
            MarkersOverlay.Graphics.Clear();
        }

        private MapPoint GetRandomPointNearLA()
        {
            // Rough bounding box around LA in WGS84
            double minLon = -118.7, maxLon = -117.6;
            double minLat = 33.6, maxLat = 34.4;
            double lon = minLon + _random.NextDouble() * (maxLon - minLon);
            double lat = minLat + _random.NextDouble() * (maxLat - minLat);
            return (MapPoint)GeometryEngine.Project(new MapPoint(lon, lat, SpatialReferences.Wgs84), SpatialReferences.WebMercator);
        }

        private void ToggleAssetLayer()
        {
            ShowAssetLayer = !ShowAssetLayer;
            // TODO: Implement asset layer visibility logic
        }

        private void ToggleAssetDetails()
        {
            ShowAssetDetails = !ShowAssetDetails;
            // TODO: Implement asset details visibility logic
        }

        private void RotateLeft()
        {
            // TODO: Implement map rotation logic
            System.Diagnostics.Debug.WriteLine("Rotate Left clicked");
        }

        private void RotateRight()
        {
            // TODO: Implement map rotation logic
            System.Diagnostics.Debug.WriteLine("Rotate Right clicked");
        }

        private void Reset()
        {
            // Reset current map to initial viewpoint based on active tab
            switch (ActiveTab)
            {
                case "LIVE MAP":
                    LiveWorldMap.InitialViewpoint = new Viewpoint(
                        new MapPoint(-118.2437, 34.0522, SpatialReferences.Wgs84),
                        1000000
                    );
                    break;
                // Removed L.A. CITY case
                case "OFFLINE MAP":
                    OfflineMap.InitialViewpoint = new Viewpoint(
                        new MapPoint(-118.2437, 34.0522, SpatialReferences.Wgs84),
                        1000000
                    );
                    break;
            }
            System.Diagnostics.Debug.WriteLine("Reset clicked");
        }

        private void LoadVtpk()
        {
            try
            {
                // Get the path to the VTPK file in the Data folder
                string vtpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "Naperville.vtpk");

                if (!System.IO.File.Exists(vtpkPath))
                {
                    System.Windows.MessageBox.Show(
                        $"VTPK file not found at: {vtpkPath}", 
                        "File Not Found", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Warning);
                    return;
                }

                // For now, we'll use a local tile layer approach
                // Note: VTPK loading requires specific ArcGIS Runtime version support
                // This is a placeholder implementation
                var basemap = new Basemap(BasemapStyle.ArcGISStreets);
                
                // Update the offline map with the VTPK basemap
                OfflineMap.Basemap = basemap;
                
                // Set a suitable initial viewpoint for the VTPK data
                // You may need to adjust these coordinates based on your VTPK data
                OfflineMap.InitialViewpoint = new Viewpoint(
                    new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                    50000 // Zoom level
                );

                // Update status
                OfflineDataStatus = "VTPK placeholder loaded (requires ArcGIS Runtime update)";
                
                System.Windows.MessageBox.Show(
                    "VTPK loading is currently a placeholder. Full VTPK support requires ArcGIS Runtime version update.", 
                    "Info", 
                    System.Windows.MessageBoxButton.OK, 
                    System.Windows.MessageBoxImage.Information);
                
                System.Diagnostics.Debug.WriteLine($"VTPK loaded from: {vtpkPath}");
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(
                    $"Error loading VTPK file: {ex.Message}", 
                    "Error", 
                    System.Windows.MessageBoxButton.OK, 
                    System.Windows.MessageBoxImage.Error);
                
                System.Diagnostics.Debug.WriteLine($"Error loading VTPK: {ex}");
            }
        }

        private async void LoadMmpk()
        {
            try
            {
                // Get the path to the MMPK file in the Data folder
                string mmpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "NapervilleWaterUtility.mmpk");

                if (!System.IO.File.Exists(mmpkPath))
                {
                    System.Windows.MessageBox.Show(
                        $"MMPK file not found at: {mmpkPath}", 
                        "File Not Found", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Warning);
                    return;
                }

                // Load the MMPK file
                var mmpk = await Esri.ArcGISRuntime.Mapping.MobileMapPackage.OpenAsync(mmpkPath);
                
                if (mmpk.Maps.Count > 0)
                {
                    // Get the first map from the MMPK
                    var mobileMap = mmpk.Maps[0];
                    
                    // Replace the current offline map with the mobile map
                    OfflineMap = mobileMap;
                    
                    // Update status
                    OfflineDataStatus = $"MMPK loaded successfully";
                    
                    System.Windows.MessageBox.Show(
                        $"MMPK file loaded successfully!", 
                        "Success", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Information);
                    
                    System.Diagnostics.Debug.WriteLine($"MMPK loaded from: {mmpkPath}");
                }
                else
                {
                    System.Windows.MessageBox.Show(
                        "No maps found in the MMPK file.", 
                        "Warning", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(
                    $"Error loading MMPK file: {ex.Message}", 
                    "Error", 
                    System.Windows.MessageBoxButton.OK, 
                    System.Windows.MessageBoxImage.Error);
                
                System.Diagnostics.Debug.WriteLine($"Error loading MMPK: {ex}");
            }
        }
    }
}
