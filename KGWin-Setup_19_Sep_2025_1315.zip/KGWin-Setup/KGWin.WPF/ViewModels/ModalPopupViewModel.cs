using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace KGWin.WPF.ViewModels
{
    public class ModalPopupConfig
    {
        public bool ShowBackdrop { get; set; } = true;
        public bool CloseOnBackdropClick { get; set; } = true;
        public bool CloseOnEscape { get; set; } = true;
        public bool ShowHeader { get; set; } = true;
        public bool ShowCloseButton { get; set; } = true;
        public bool ShowFooter { get; set; } = false;
        public bool ShowOkButton { get; set; } = false;
        public bool ShowCancelButton { get; set; } = false;
        public bool AutoFitContent { get; set; } = false;
        public double Width { get; set; } = 800;
        public double Height { get; set; } = 600;
        public double MinWidth { get; set; } = 600;
        public double MinHeight { get; set; } = 400;
        public double MaxWidth { get; set; } = 1200;
        public double MaxHeight { get; set; } = 800;
        public ResizeMode ResizeMode { get; set; } = ResizeMode.CanResize;
        public object? FooterContent { get; set; }
    }

    public class ModalPopupViewModel : INotifyPropertyChanged
    {
        private string _title = "Popup";
        private object? _content;
        private ModalPopupConfig? _config;

        public ModalPopupViewModel()
        {
            _config = new ModalPopupConfig();
        }

        public ModalPopupViewModel(string title, object content, ModalPopupConfig? config = null)
        {
            _title = title;
            _content = content;
            _config = config ?? new ModalPopupConfig();
        }

        public string Title
        {
            get => _title;
            set => SetProperty(ref _title, value);
        }

        public object? Content
        {
            get => _content;
            set => SetProperty(ref _content, value);
        }

        public ModalPopupConfig? Config
        {
            get => _config;
            set => SetProperty(ref _config, value);
        }

        // Configuration Properties
        public bool ShowBackdrop => _config?.ShowBackdrop ?? true;
        public bool CloseOnBackdropClick => _config?.CloseOnBackdropClick ?? true;
        public bool CloseOnEscape => _config?.CloseOnEscape ?? true;
        public bool ShowHeader => _config?.ShowHeader ?? true;
        public bool ShowCloseButton => _config?.ShowCloseButton ?? true;
        public bool ShowFooter => _config?.ShowFooter ?? false;
        public bool ShowOkButton => _config?.ShowOkButton ?? false;
        public bool ShowCancelButton => _config?.ShowCancelButton ?? false;
        public double Width => (_config?.AutoFitContent ?? false) ? double.NaN : (_config?.Width ?? 800);
        public double Height => (_config?.AutoFitContent ?? false) ? double.NaN : (_config?.Height ?? 600);
        public double MinWidth => _config?.MinWidth ?? 600;
        public double MinHeight => _config?.MinHeight ?? 400;
        public double MaxWidth => _config?.MaxWidth ?? 1200;
        public double MaxHeight => _config?.MaxHeight ?? 800;
        public ResizeMode ResizeMode => _config?.ResizeMode ?? ResizeMode.CanResize;
        public object? FooterContent => _config?.FooterContent;

        // Events
        public Action? OnOk { get; set; }
        public Action? OnCancel { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        public void UpdateConfig(ModalPopupConfig newConfig)
        {
            _config = newConfig;
            // Notify all configuration properties have changed
            OnPropertyChanged(nameof(ShowBackdrop));
            OnPropertyChanged(nameof(CloseOnBackdropClick));
            OnPropertyChanged(nameof(CloseOnEscape));
            OnPropertyChanged(nameof(ShowHeader));
            OnPropertyChanged(nameof(ShowCloseButton));
            OnPropertyChanged(nameof(ShowFooter));
            OnPropertyChanged(nameof(ShowOkButton));
            OnPropertyChanged(nameof(ShowCancelButton));
            OnPropertyChanged(nameof(Width));
            OnPropertyChanged(nameof(Height));
            OnPropertyChanged(nameof(Width));
            OnPropertyChanged(nameof(Height));
            OnPropertyChanged(nameof(MinWidth));
            OnPropertyChanged(nameof(MinHeight));
            OnPropertyChanged(nameof(MaxWidth));
            OnPropertyChanged(nameof(MaxHeight));
            OnPropertyChanged(nameof(ResizeMode));
            OnPropertyChanged(nameof(FooterContent));
        }
    }

    // Value Converters for XAML
    public class BooleanToVisibilityConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value is bool boolValue && boolValue ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value is Visibility visibility && visibility == Visibility.Visible;
        }
    }

    public class HeaderCornerRadiusConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is bool showHeader)
            {
                return showHeader ? new CornerRadius(0) : new CornerRadius(8, 8, 0, 0);
            }
            return new CornerRadius(0);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class CenterXConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double windowWidth)
            {
                return (windowWidth - 800) / 2; // Center the 800px wide popup
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class CenterYConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double windowHeight)
            {
                return (windowHeight - 600) / 2; // Center the 600px tall popup
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
