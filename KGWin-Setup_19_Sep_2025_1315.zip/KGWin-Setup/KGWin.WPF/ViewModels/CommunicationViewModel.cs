using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows;
using KGWin.WPF.ViewModels.Base;

namespace KGWin.WPF.ViewModels
{
    public enum MessageType
    {
        Sent,
        Received,
        System
    }

    public class ChatMessage
    {
        public string Message { get; set; } = string.Empty;
        public string Sender { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.Now;
        public MessageType Type { get; set; } = MessageType.System;

        public bool IsSent => Type == MessageType.Sent;
        public bool IsReceived => Type == MessageType.Received;
        public bool IsSystem => Type == MessageType.System;
    }

    public class CommunicationViewModel : ViewModelBase
    {
        private string _communicationStatus = "Ready";
        private string _newMessage = string.Empty;
        private readonly ObservableCollection<ChatMessage> _chatMessages;

        public CommunicationViewModel()
        {
            _chatMessages = new ObservableCollection<ChatMessage>();
            
            // Initialize commands
            SendMessageCommand = new RelayCommand(_ => SendMessage(), _ => CanSendMessage);
            ClearChatCommand = new RelayCommand(_ => ClearChat());
            AddRandomAssetsCommand = new RelayCommand(_ => AddRandomAssets());
            AddRandomMarkersCommand = new RelayCommand(_ => AddRandomMarkers());
            
            // Add system message to indicate chat is ready
            AddSystemMessage("Communication system ready. Messages from Web will appear here.");
        }

        public string CommunicationStatus
        {
            get => _communicationStatus;
            set => SetProperty(ref _communicationStatus, value);
        }

        public string NewMessage
        {
            get => _newMessage;
            set
            {
                SetProperty(ref _newMessage, value);
                OnPropertyChanged(nameof(CanSendMessage));
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public ObservableCollection<ChatMessage> ChatMessages
        {
            get => _chatMessages;
        }

        public ICommand SendMessageCommand { get; }
        public ICommand ClearChatCommand { get; }
        public ICommand AddRandomAssetsCommand { get; }
        public ICommand AddRandomMarkersCommand { get; }

        public bool CanSendMessage => !string.IsNullOrWhiteSpace(NewMessage);

        private void SendMessage()
        {
            if (string.IsNullOrWhiteSpace(NewMessage))
                return;

            var messageText = NewMessage.Trim();
            NewMessage = string.Empty;

            // Add message to local chat
            var message = new ChatMessage
            {
                Message = messageText,
                Type = MessageType.Sent,
                Timestamp = DateTime.Now
            };

            _chatMessages.Add(message);
            UpdateStatus($"Message sent at {message.Timestamp:HH:mm:ss}");

            // Send message to Angular application
            SendMessageToAngularViaMainViewModel(messageText);
        }

        private void SimulateReceivedMessage()
        {
            // Simulate a response after 1-3 seconds
            var random = new Random();
            var delay = random.Next(1000, 3000);
            
            System.Threading.Tasks.Task.Delay(delay).ContinueWith(_ =>
            {
                var responses = new[]
                {
                    "Thanks for your message!",
                    "I received your message.",
                    "Got it!",
                    "Message received and processed.",
                    "Thanks for reaching out!",
                    "I'm here to help!",
                    "Your message has been noted.",
                    "Understood!",
                    "Great to hear from you!",
                    "Message acknowledged."
                };

                var response = responses[random.Next(responses.Length)];
                var receivedMessage = new ChatMessage
                {
                    Message = response,
                    Sender = "System",
                    Type = MessageType.Received,
                    Timestamp = DateTime.Now
                };

                // Use Dispatcher to update UI from background thread
                System.Windows.Application.Current.Dispatcher.Invoke(() =>
                {
                    _chatMessages.Add(receivedMessage);
                    UpdateStatus($"Response received at {receivedMessage.Timestamp:HH:mm:ss}");
                });
            });
        }

        private void AddRandomAssets()
        {
            var random = new Random();
            var randomAssets = new
            {
                assets = new[]
                {
                    new
                    {
                        id = "asset_" + Guid.NewGuid().ToString("N").Substring(0, 6),
                        name = "Asset " + random.Next(100),
                        type = "Equipment",
                        status = new[] { "Active", "Inactive" }[random.Next(2)],
                        location = new
                        {
                            longitude = -118.2437 + (random.NextDouble() - 0.5) * 0.8,
                            latitude = 34.0522 + (random.NextDouble() - 0.5) * 0.6
                        }
                    },
                    new
                    {
                        id = "asset_" + Guid.NewGuid().ToString("N").Substring(0, 6),
                        name = "Asset " + random.Next(100),
                        type = "Vehicle",
                        status = new[] { "Active", "Inactive" }[random.Next(2)],
                        location = new
                        {
                            longitude = -118.2437 + (random.NextDouble() - 0.5) * 0.8,
                            latitude = 34.0522 + (random.NextDouble() - 0.5) * 0.6
                        }
                    }
                }
            };

            var jsonString = System.Text.Json.JsonSerializer.Serialize(randomAssets, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
            NewMessage = jsonString;
            AddSystemMessage("Random assets JSON added to input");
        }

        private void AddRandomMarkers()
        {
            var random = new Random();
            var randomMarkers = new
            {
                markers = new[]
                {
                    new
                    {
                        id = "marker_" + Guid.NewGuid().ToString("N").Substring(0, 6),
                        title = "Marker " + random.Next(100),
                        type = new[] { "POI", "Alert", "Task" }[random.Next(3)],
                        location = new
                        {
                            longitude = -118.2437 + (random.NextDouble() - 0.5) * 0.8,
                            latitude = 34.0522 + (random.NextDouble() - 0.5) * 0.6
                        }
                    },
                    new
                    {
                        id = "marker_" + Guid.NewGuid().ToString("N").Substring(0, 6),
                        title = "Marker " + random.Next(100),
                        type = new[] { "POI", "Alert", "Task" }[random.Next(3)],
                        location = new
                        {
                            longitude = -118.2437 + (random.NextDouble() - 0.5) * 0.8,
                            latitude = 34.0522 + (random.NextDouble() - 0.5) * 0.6
                        }
                    }
                }
            };

            var jsonString = System.Text.Json.JsonSerializer.Serialize(randomMarkers, new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
            NewMessage = jsonString;
            AddSystemMessage("Random markers JSON added to input");
        }

        private void ClearChat()
        {
            _chatMessages.Clear();
            AddSystemMessage("Chat cleared. Start a new conversation!");
            UpdateStatus("Chat cleared");
        }

        public void AddSystemMessage(string message)
        {
            // System message for internal use
        }

        public void AddReceivedMessage(string message, string sender = "Unknown")
        {
            var receivedMessage = new ChatMessage
            {
                Message = message,
                Sender = sender,
                Type = MessageType.Received,
                Timestamp = DateTime.Now
            };

            _chatMessages.Add(receivedMessage);
            UpdateStatus($"Message from {sender} received at {receivedMessage.Timestamp:HH:mm:ss}");
        }

        public void UpdateStatus(string status)
        {
            CommunicationStatus = status;
        }

        // Handle messages from Angular application
        public void HandleMessageFromAngular(string messageType, object data)
        {
            var message = new ChatMessage
            {
                Message = data.ToString() ?? "No data",
                Sender = "Angular App",
                Type = MessageType.Received,
                Timestamp = DateTime.Now
            };

            _chatMessages.Add(message);
            UpdateStatus($"Message from Angular received at {message.Timestamp:HH:mm:ss}");
        }

        // Handle chat messages from Angular
        public void HandleChatMessageFromAngular(string messageText)
        {
            var message = new ChatMessage
            {
                Message = messageText,
                Sender = "Web",
                Type = MessageType.Received,
                Timestamp = DateTime.Now
            };

            _chatMessages.Add(message);
            UpdateStatus($"Chat message from Angular received at {message.Timestamp:HH:mm:ss}");

            // Check if the message contains assets or markers data
            HandleMapDataFromMessage(messageText);
        }

        private void HandleMapDataFromMessage(string messageText)
        {
            try
            {
                // Try to parse as JSON
                var jsonData = System.Text.Json.JsonSerializer.Deserialize<System.Text.Json.JsonElement>(messageText);
                
                // Check for assets
                if (jsonData.TryGetProperty("assets", out var assetsElement) && assetsElement.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    var assets = assetsElement.EnumerateArray().ToList();
                    AddAssetsFromMessage(assets);
                }
                
                // Check for markers
                if (jsonData.TryGetProperty("markers", out var markersElement) && markersElement.ValueKind == System.Text.Json.JsonValueKind.Array)
                {
                    var markers = markersElement.EnumerateArray().ToList();
                    AddMarkersFromMessage(markers);
                }
            }
            catch (Exception ex)
            {
                // Not JSON or parsing failed, ignore
                System.Diagnostics.Debug.WriteLine($"Error parsing message as JSON: {ex.Message}");
            }
        }

        private void AddAssetsFromMessage(System.Collections.Generic.List<System.Text.Json.JsonElement> assets)
        {
            if (MainViewModel?.MapViewModel != null)
            {
                // Clear existing assets
                MainViewModel.MapViewModel.AssetsOverlay.Graphics.Clear();
                
                var random = new Random();
                foreach (var asset in assets)
                {
                    Esri.ArcGISRuntime.Geometry.MapPoint point;
                    
                    // Try to get location from asset
                    if (asset.TryGetProperty("location", out var locationElement))
                    {
                        var longitude = locationElement.TryGetProperty("longitude", out var lon) ? lon.GetDouble() : -118.2437;
                        var latitude = locationElement.TryGetProperty("latitude", out var lat) ? lat.GetDouble() : 34.0522;
                        point = (Esri.ArcGISRuntime.Geometry.MapPoint)Esri.ArcGISRuntime.Geometry.GeometryEngine.Project(
                            new Esri.ArcGISRuntime.Geometry.MapPoint(longitude, latitude, Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84), 
                            Esri.ArcGISRuntime.Geometry.SpatialReferences.WebMercator);
                    }
                    else
                    {
                        point = GetRandomPointNearLA(random);
                    }
                    
                    var symbol = new Esri.ArcGISRuntime.Symbology.SimpleMarkerSymbol(
                        Esri.ArcGISRuntime.Symbology.SimpleMarkerSymbolStyle.Triangle, 
                        System.Drawing.Color.FromArgb(255, 107, 53), // Highlighted orange color
                        20); // Larger size for highlighted assets
                    
                    // Determine WGS84 lon/lat for attributes
                    var attrLonLat = point.SpatialReference == Esri.ArcGISRuntime.Geometry.SpatialReferences.WebMercator
                        ? (Esri.ArcGISRuntime.Geometry.MapPoint)Esri.ArcGISRuntime.Geometry.GeometryEngine.Project(point, Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84)
                        : point;

                    var graphic = new Esri.ArcGISRuntime.UI.Graphic(point, symbol)
                    {
                        Attributes = { 
                            ["type"] = "asset", 
                            ["id"] = asset.TryGetProperty("id", out var id) ? id.GetString() : $"asset_{Guid.NewGuid():N}".Substring(0, 6),
                            ["title"] = asset.TryGetProperty("name", out var name) ? name.GetString() : "Asset",
                            ["color"] = "#FF6B35",
                            ["longitude"] = locationElement.ValueKind != System.Text.Json.JsonValueKind.Undefined ? (object)locationElement.GetProperty("longitude").GetDouble() : attrLonLat.X,
                            ["latitude"] = locationElement.ValueKind != System.Text.Json.JsonValueKind.Undefined ? (object)locationElement.GetProperty("latitude").GetDouble() : attrLonLat.Y,
                            ["fromMessage"] = true
                        }
                    };
                    MainViewModel.MapViewModel.AssetsOverlay.Graphics.Add(graphic);
                }
                
                AddSystemMessage($"Added {assets.Count} assets from message to WPF map");
            }
        }

        private void AddMarkersFromMessage(System.Collections.Generic.List<System.Text.Json.JsonElement> markers)
        {
            if (MainViewModel?.MapViewModel != null)
            {
                // Clear existing markers
                MainViewModel.MapViewModel.MarkersOverlay.Graphics.Clear();
                
                var random = new Random();
                foreach (var marker in markers)
                {
                    Esri.ArcGISRuntime.Geometry.MapPoint point;
                    
                    // Try to get location from marker
                    if (marker.TryGetProperty("location", out var locationElement))
                    {
                        var longitude = locationElement.TryGetProperty("longitude", out var lon) ? lon.GetDouble() : -118.2437;
                        var latitude = locationElement.TryGetProperty("latitude", out var lat) ? lat.GetDouble() : 34.0522;
                        point = (Esri.ArcGISRuntime.Geometry.MapPoint)Esri.ArcGISRuntime.Geometry.GeometryEngine.Project(
                            new Esri.ArcGISRuntime.Geometry.MapPoint(longitude, latitude, Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84), 
                            Esri.ArcGISRuntime.Geometry.SpatialReferences.WebMercator);
                    }
                    else
                    {
                        point = GetRandomPointNearLA(random);
                    }
                    
                    var symbol = new Esri.ArcGISRuntime.Symbology.SimpleMarkerSymbol(
                        Esri.ArcGISRuntime.Symbology.SimpleMarkerSymbolStyle.Triangle, 
                        System.Drawing.Color.FromArgb(255, 215, 0), // Highlighted gold color
                        20); // Larger size for highlighted markers
                    
                    // Determine WGS84 lon/lat for attributes
                    var attrLonLat = point.SpatialReference == Esri.ArcGISRuntime.Geometry.SpatialReferences.WebMercator
                        ? (Esri.ArcGISRuntime.Geometry.MapPoint)Esri.ArcGISRuntime.Geometry.GeometryEngine.Project(point, Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84)
                        : point;

                    var graphic = new Esri.ArcGISRuntime.UI.Graphic(point, symbol)
                    {
                        Attributes = { 
                            ["type"] = "marker", 
                            ["id"] = marker.TryGetProperty("id", out var id) ? id.GetString() : $"marker_{Guid.NewGuid():N}".Substring(0, 6),
                            ["title"] = marker.TryGetProperty("title", out var title) ? title.GetString() : "Marker",
                            ["color"] = "#FFD700",
                            ["longitude"] = marker.TryGetProperty("location", out var _) ? (object)locationElement.GetProperty("longitude").GetDouble() : attrLonLat.X,
                            ["latitude"] = marker.TryGetProperty("location", out var _) ? (object)locationElement.GetProperty("latitude").GetDouble() : attrLonLat.Y,
                            ["fromMessage"] = true
                        }
                    };
                    MainViewModel.MapViewModel.MarkersOverlay.Graphics.Add(graphic);
                }
                
                AddSystemMessage($"Added {markers.Count} markers from message to WPF map");
            }
        }

        private Esri.ArcGISRuntime.Geometry.MapPoint GetRandomPointNearLA(Random random)
        {
            // Rough bounding box around LA in WGS84
            double minLon = -118.7, maxLon = -117.6;
            double minLat = 33.6, maxLat = 34.4;
            double lon = minLon + random.NextDouble() * (maxLon - minLon);
            double lat = minLat + random.NextDouble() * (maxLat - minLat);
            return (Esri.ArcGISRuntime.Geometry.MapPoint)Esri.ArcGISRuntime.Geometry.GeometryEngine.Project(
                new Esri.ArcGISRuntime.Geometry.MapPoint(lon, lat, Esri.ArcGISRuntime.Geometry.SpatialReferences.Wgs84), 
                Esri.ArcGISRuntime.Geometry.SpatialReferences.WebMercator);
        }

        // Send message to Angular application
        public void SendMessageToAngular(string messageText)
        {
            // This method is called when we want to send a message to Angular
            // The message is already added to the local chat in SendMessage()
            UpdateStatus($"Message sent to Angular at {DateTime.Now:HH:mm:ss}");
            
            // Try to send the message to Angular via the WebView
            // This will be handled by the MainViewModel when the Web page is active
        }

        // Reference to MainViewModel for communication
        public MainViewModel? MainViewModel { get; set; }

        // Method to send message to Angular via MainViewModel
        public void SendMessageToAngularViaMainViewModel(string messageText)
        {
            if (MainViewModel != null)
            {
                MainViewModel.SendMessageToAngularViaWebView(messageText);
            }
            else
            {
                // Fallback: try to find the CSWebView directly
                var mainWindow = System.Windows.Application.Current.MainWindow;
                if (mainWindow?.DataContext is MainViewModel mainVM)
                {
                    mainVM.SendMessageToAngularViaWebView(messageText);
                }
            }
        }

        // Legacy method for backward compatibility
        public void AddMessage(string type, object data)
        {
            var message = new ChatMessage
            {
                Message = data.ToString() ?? "No data",
                Sender = type,
                Type = MessageType.Received,
                Timestamp = DateTime.Now
            };

            _chatMessages.Add(message);
            UpdateStatus($"Legacy message received: {type}");
        }
    }
}
