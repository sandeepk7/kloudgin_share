# KGWin.MSI Configuration Helper Script
# This script helps verify and configure the Visual Studio Setup Project

Write-Host "KGWin.MSI Configuration Helper" -ForegroundColor Green
Write-Host "==============================" -ForegroundColor Green
Write-Host ""

# Check if Visual Studio is installed
Write-Host "Checking Visual Studio installation..." -ForegroundColor Yellow
$vsPaths = @(
    "${env:ProgramFiles}\Microsoft Visual Studio\2022\Community\Common7\IDE\devenv.exe",
    "${env:ProgramFiles}\Microsoft Visual Studio\2022\Professional\Common7\IDE\devenv.exe",
    "${env:ProgramFiles}\Microsoft Visual Studio\2022\Enterprise\Common7\IDE\devenv.exe"
)

$vsFound = $false
foreach ($path in $vsPaths) {
    if (Test-Path $path) {
        Write-Host "✓ Visual Studio 2022 found at: $path" -ForegroundColor Green
        $vsFound = $true
        break
    }
}

if (-not $vsFound) {
    Write-Host "✗ Visual Studio 2022 not found" -ForegroundColor Red
    Write-Host "Please install Visual Studio 2022 first" -ForegroundColor Red
    exit 1
}

# Check if the solution file exists
Write-Host ""
Write-Host "Checking solution file..." -ForegroundColor Yellow
$solutionPath = "..\KGWin.sln"
if (Test-Path $solutionPath) {
    Write-Host "✓ Solution file found: $solutionPath" -ForegroundColor Green
} else {
    Write-Host "✗ Solution file not found: $solutionPath" -ForegroundColor Red
    exit 1
}

# Check if KGWin.WPF project exists
Write-Host ""
Write-Host "Checking KGWin.WPF project..." -ForegroundColor Yellow
$wpfProjectPath = "..\KGWin.WPF\KGWin.WPF.csproj"
if (Test-Path $wpfProjectPath) {
    Write-Host "✓ KGWin.WPF project found" -ForegroundColor Green
} else {
    Write-Host "✗ KGWin.WPF project not found" -ForegroundColor Red
    exit 1
}

# Check if MSI project exists
Write-Host ""
Write-Host "Checking KGWin.MSI project..." -ForegroundColor Yellow
$msiProjectPath = "KGWin.MSI.vdproj"
if (Test-Path $msiProjectPath) {
    Write-Host "✓ KGWin.MSI project found" -ForegroundColor Green
} else {
    Write-Host "✗ KGWin.MSI project not found" -ForegroundColor Red
    Write-Host "Please create the MSI project in Visual Studio first" -ForegroundColor Red
    exit 1
}

# Check build output directories
Write-Host ""
Write-Host "Checking build output directories..." -ForegroundColor Yellow
if (Test-Path "Debug") {
    Write-Host "✓ Debug directory exists" -ForegroundColor Green
} else {
    Write-Host "! Debug directory not found (will be created on first build)" -ForegroundColor Yellow
}

if (Test-Path "Release") {
    Write-Host "✓ Release directory exists" -ForegroundColor Green
} else {
    Write-Host "! Release directory not found (will be created on first build)" -ForegroundColor Yellow
}

# Display configuration steps
Write-Host ""
Write-Host "Next Steps for Configuration:" -ForegroundColor Cyan
Write-Host "============================" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Open Visual Studio 2022" -ForegroundColor White
Write-Host "2. Open the KGWin.sln solution" -ForegroundColor White
Write-Host "3. Follow the Configuration_Guide.md for detailed steps" -ForegroundColor White
Write-Host ""
Write-Host "Key Configuration Steps:" -ForegroundColor Yellow
Write-Host "- Add Project Output (Primary output from KGWin.WPF)" -ForegroundColor White
Write-Host "- Set Installer Properties (Product Name, Manufacturer, Version)" -ForegroundColor White
Write-Host "- Configure Prerequisites (.NET 8.0, VC++ Redistributable)" -ForegroundColor White
Write-Host "- Add Desktop and Start Menu Shortcuts" -ForegroundColor White
Write-Host "- Build the installer project" -ForegroundColor White
Write-Host ""

# Ask if user wants to open files
$openSolution = Read-Host "Do you want to open the solution in Visual Studio? (y/n)"
if ($openSolution -eq "y" -or $openSolution -eq "Y") {
    Write-Host "Opening solution in Visual Studio..." -ForegroundColor Green
    Start-Process $solutionPath
}

$openGuide = Read-Host "Do you want to open the configuration guide? (y/n)"
if ($openGuide -eq "y" -or $openGuide -eq "Y") {
    Write-Host "Opening configuration guide..." -ForegroundColor Green
    Start-Process "Configuration_Guide.md"
}

Write-Host ""
Write-Host "Configuration helper completed!" -ForegroundColor Green
Write-Host "Follow the Configuration_Guide.md for detailed setup instructions." -ForegroundColor Green
