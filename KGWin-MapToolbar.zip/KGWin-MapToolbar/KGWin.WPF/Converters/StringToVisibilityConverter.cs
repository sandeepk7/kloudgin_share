using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace KGWin.WPF.Converters
{
    public class StringToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            System.Diagnostics.Debug.WriteLine($"StringToVisibilityConverter: value='{value}', parameter='{parameter}'");
            if (value is string currentPage && parameter is string targetPage)
            {
                var result = currentPage == targetPage ? Visibility.Visible : Visibility.Collapsed;
                System.Diagnostics.Debug.WriteLine($"StringToVisibilityConverter: {currentPage} == {targetPage} = {result}");
                return result;
            }
            System.Diagnostics.Debug.WriteLine("StringToVisibilityConverter: returning Collapsed (no match)");
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
