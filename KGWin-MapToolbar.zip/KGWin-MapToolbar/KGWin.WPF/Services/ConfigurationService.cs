using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KGWin.WPF.Services
{
    public class ConfigurationService
    {
        private static readonly IConfiguration _configuration;

        static ConfigurationService()
        {
            // Determine environment - check multiple sources
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")
                            ?? Environment.GetEnvironmentVariable("DOTNET_ENVIRONMENT")
                            ?? (System.Diagnostics.Debugger.IsAttached ? "Development" : "Production");

            System.Diagnostics.Debug.WriteLine($"ConfigurationService: Loading environment: {environment}");
            System.Diagnostics.Debug.WriteLine($"ConfigurationService: Debugger attached: {System.Diagnostics.Debugger.IsAttached}");

            var builder = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();

            _configuration = builder.Build();

            // Log the browser address that was loaded
            var browserAddress = _configuration["Browser:Address"];
            System.Diagnostics.Debug.WriteLine($"ConfigurationService: Loaded Browser:Address = {browserAddress}");
        }

        public static IConfiguration Configuration => _configuration;

        public IConfiguration BuildConfiguration()
        {
            // Backward compatible API: return the shared instance
            return _configuration;
        }

        public ILoggerFactory CreateLoggerFactory(IConfiguration configuration)
        {
            return LoggerFactory.Create(builder =>
                builder.AddConfiguration(configuration.GetSection("Logging"))
                       .AddConsole()
                       .AddDebug());
        }

        public ILogger<T> CreateLogger<T>(ILoggerFactory factory)
        {
            return factory.CreateLogger<T>();
        }
    }
}


