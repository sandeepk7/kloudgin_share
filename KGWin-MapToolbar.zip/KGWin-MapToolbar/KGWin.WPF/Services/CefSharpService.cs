using System;
using CefSharp;
using CefSharp.Wpf;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KGWin.WPF.Services
{
    public class CefSharpService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private bool _initialized;

        public CefSharpService(IConfiguration configuration, ILogger logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public void Initialize()
        {
            if (_initialized) return;

            try
            {
                var settings = new CefSettings();

                var cachePath = _configuration["CefSharp:CachePath"] ?? "KGwin\\CefSharp\\Cache";
                settings.CachePath = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
                    cachePath);

                if (_configuration.GetValue<bool>("CefSharp:PersistSessionCookies"))
                {
                    settings.CefCommandLineArgs.Add("persist_session_cookies", "1");
                }

                if (_configuration.GetValue<bool>("CefSharp:PersistUserPreferences"))
                {
                    settings.CefCommandLineArgs.Add("persist_user_preferences", "1");
                }

                if (!_configuration.GetValue<bool>("CefSharp:EnableGPUAcceleration"))
                {
                    settings.CefCommandLineArgs.Add("disable-gpu", "1");
                }

                if (_configuration.GetValue<bool>("CefSharp:DisableWebSecurity"))
                {
                    settings.CefCommandLineArgs.Add("disable-web-security", "1");
                }

                if (_configuration.GetValue<bool>("CefSharp:AllowRunningInsecureContent"))
                {
                    settings.CefCommandLineArgs.Add("allow-running-insecure-content", "1");
                }

                Cef.Initialize(settings, performDependencyCheck: true, browserProcessHandler: null);
                _initialized = true;
                _logger.LogInformation("CefSharpService: Cef initialized");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "CefSharpService: Cef initialization failed");
                throw;
            }
        }

        public void Shutdown()
        {
            if (!_initialized) return;
            _logger.LogInformation("CefSharpService: Shutting down");
            Cef.Shutdown();
            _initialized = false;
        }
    }
}


