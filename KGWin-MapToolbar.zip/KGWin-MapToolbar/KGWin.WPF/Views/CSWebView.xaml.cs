using System.Windows.Controls;
using System.ComponentModel;
using KGWin.WPF.ViewModels;
using KGWin.WPF.Services;
using System;
using CefSharp;
using System.Windows;
using System.Threading.Tasks;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for CSWebView.xaml
    /// </summary>
    public partial class CSWebView : UserControl
    {
        private CommunicationService? _communicationService;
        private bool _isCommunicationServiceInitialized = false;

        public CSWebView()
        {
            InitializeComponent();
            this.DataContextChanged += CSWebView_DataContextChanged;
            
            // Don't set browser address here - let the DataContext handle it
            // This prevents overriding the ViewModel's configured address
            
            // Initialize communication service
            _communicationService = new CommunicationService();
            
            // Add browser initialization handler
            Browser.IsBrowserInitializedChanged += Browser_IsBrowserInitializedChanged;
            
            // Add browser load event handler
            Browser.FrameLoadEnd += Browser_FrameLoadEnd;
        }

        private void CSWebView_DataContextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue is CSWebViewModel viewModel)
            {
                System.Diagnostics.Debug.WriteLine($"CSWebView: DataContext changed, BrowserAddress = {viewModel.BrowserAddress}");
                
                // Remove previous property changed handler
                if (e.OldValue is CSWebViewModel oldViewModel)
                {
                    oldViewModel.PropertyChanged -= ViewModel_PropertyChanged;
                }

                // Add new property changed handler
                viewModel.PropertyChanged += ViewModel_PropertyChanged;
                
                // Set initial address
                if (!string.IsNullOrEmpty(viewModel.BrowserAddress))
                {
                    Browser.Address = viewModel.BrowserAddress;
                    System.Diagnostics.Debug.WriteLine($"CSWebView: Set browser address from viewModel to: {viewModel.BrowserAddress}");
                }
                else
                {
                    // Fallback to configuration if ViewModel doesn't have address
                    var configuredAddress = App.Configuration?["Browser:Address"] ?? "http://localhost:4200";
                    Browser.Address = configuredAddress;
                    System.Diagnostics.Debug.WriteLine($"CSWebView: Set browser address from configuration fallback to: {configuredAddress}");
                }
                
                // Connect this CSWebView to the MainViewModel for communication
                ConnectToMainViewModel();
            }
        }
        
        private void ConnectToMainViewModel()
        {
            // Try to find MainViewModel in the application's main window
            if (Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel)
            {
                mainViewModel.CSWebView = this;
                System.Diagnostics.Debug.WriteLine("CSWebView: Connected to MainViewModel for communication");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("CSWebView: Could not find MainViewModel to connect");
            }
        }

        private void ViewModel_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(CSWebViewModel.BrowserAddress))
            {
                if (sender is CSWebViewModel viewModel && !string.IsNullOrEmpty(viewModel.BrowserAddress))
                {
                    System.Diagnostics.Debug.WriteLine($"CSWebView: BrowserAddress property changed to: {viewModel.BrowserAddress}");
                    Browser.Address = viewModel.BrowserAddress;
                }
            }
        }

        private void Browser_IsBrowserInitializedChanged(object? sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            if (Browser.IsBrowserInitialized)
            {
                System.Diagnostics.Debug.WriteLine("CSWebView: Browser initialized, registering communication service");
                
                // Register communication service immediately when browser is ready
                if (_communicationService != null && !_isCommunicationServiceInitialized)
                {
                    _communicationService.Initialize(Browser);
                    SetupCommunicationHandlers();
                    _isCommunicationServiceInitialized = true;
                    System.Diagnostics.Debug.WriteLine("CSWebView: Communication service registered on browser initialization");
                }
            }
        }

        private void Browser_FrameLoadEnd(object? sender, CefSharp.FrameLoadEndEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"CSWebView: Frame load ended for URL: {e.Url}");
            
            // Double-check communication service is initialized
            if (_communicationService != null && !_isCommunicationServiceInitialized)
            {
                _communicationService.Initialize(Browser);
                SetupCommunicationHandlers();
                _isCommunicationServiceInitialized = true;
                System.Diagnostics.Debug.WriteLine("CSWebView: Communication service initialized after page load (fallback)");
            }

            // Try to initialize communication service with retry mechanism
            _ = Task.Run(async () => await RetryInitializeCommunicationService());
        }

        private async Task RetryInitializeCommunicationService()
        {
            if (_communicationService == null) return;

            int maxRetries = 5;
            int retryCount = 0;
            int delayMs = 1000; // Start with 1 second delay

            while (retryCount < maxRetries && !_communicationService.IsReady())
            {
                retryCount++;
                System.Diagnostics.Debug.WriteLine($"CSWebView: Retry {retryCount}/{maxRetries} - Initializing communication service");

                try
                {
                    await Task.Delay(delayMs);
                    
                    // Check if browser is ready
                    if (!Browser.IsBrowserInitialized)
                    {
                        System.Diagnostics.Debug.WriteLine("CSWebView: Browser not initialized yet, retrying...");
                        continue;
                    }

                    // Check if V8 context is ready
                    if (!Browser.CanExecuteJavascriptInMainFrame)
                    {
                        System.Diagnostics.Debug.WriteLine("CSWebView: V8 context not ready yet, retrying...");
                        delayMs = Math.Min(delayMs * 2, 5000); // Exponential backoff, max 5 seconds
                        continue;
                    }

                    // Try to initialize communication service
                    if (!_isCommunicationServiceInitialized)
                    {
                        _communicationService.Initialize(Browser);
                        SetupCommunicationHandlers();
                        _isCommunicationServiceInitialized = true;
                        System.Diagnostics.Debug.WriteLine("CSWebView: Communication service initialized successfully on retry");
                        break;
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"CSWebView: Error during retry {retryCount}: {ex.Message}");
                }
            }

            if (retryCount >= maxRetries)
            {
                System.Diagnostics.Debug.WriteLine("CSWebView: Failed to initialize communication service after all retries");
            }
        }

        private void SetupCommunicationHandlers()
        {
            if (_communicationService == null) return;

            // Register event handlers for different message types
            _communicationService.RegisterEventHandler("notification", HandleNotification);
            _communicationService.RegisterEventHandler("data", HandleData);
            _communicationService.RegisterEventHandler("command", HandleCommand);

            // Register chat message handler
            _communicationService.RegisterChatMessageHandler(HandleChatMessage);

            // Subscribe to events
            _communicationService.MessageReceived += (sender, message) =>
            {
                System.Diagnostics.Debug.WriteLine($"CSWebView: {message}");
            };

            _communicationService.ErrorOccurred += (sender, error) =>
            {
                System.Diagnostics.Debug.WriteLine($"CSWebView Error: {error}");
            };
        }

        private void HandleChatMessage(string messageText)
        {
            if (!this.Dispatcher.CheckAccess())
            {
                this.Dispatcher.Invoke(() => HandleChatMessage(messageText));
                return;
            }

                                System.Diagnostics.Debug.WriteLine($"CSWebView: Received chat message: {messageText}");
                    
                    // Forward chat message to CommunicationViewModel
                    if (this.DataContext is MainViewModel mainViewModel && mainViewModel.CommunicationViewModel != null)
                    {
                        System.Diagnostics.Debug.WriteLine("CSWebView: Forwarding message to CommunicationViewModel");
                        mainViewModel.CommunicationViewModel.HandleChatMessageFromAngular(messageText);
                    }
                    else
                    {
                        System.Diagnostics.Debug.WriteLine("CSWebView: Could not find MainViewModel or CommunicationViewModel");
                        
                        // Try to find MainViewModel in the application's main window
                        if (Application.Current.MainWindow?.DataContext is MainViewModel mainVM && mainVM.CommunicationViewModel != null)
                        {
                            System.Diagnostics.Debug.WriteLine("CSWebView: Found MainViewModel via Application.Current.MainWindow");
                            mainVM.CommunicationViewModel.HandleChatMessageFromAngular(messageText);
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("CSWebView: Could not find MainViewModel anywhere");
                        }
                    }
                   }

        // Method to send message from WPF to Angular
        public async void SendMessageToAngular(string messageText)
        {
            if (_communicationService == null)
            {
                return;
            }

            if (!_communicationService.IsReady())
            {
                await RetryInitializeCommunicationService();
                
                if (!_communicationService.IsReady())
                {
                    return;
                }
            }

            await _communicationService.SendCommunicationMessageToAngular(messageText);
        }



        // Method to manually initialize communication service (for testing)
        public void InitializeCommunicationService()
        {
            if (_communicationService != null && !_isCommunicationServiceInitialized)
            {
                _communicationService.Initialize(Browser);
                SetupCommunicationHandlers();
                _isCommunicationServiceInitialized = true;
                System.Diagnostics.Debug.WriteLine("CSWebView: Communication service manually initialized");
            }
        }

        private void HandleNotification(object data)
        {
            // Handle notifications from web app
            System.Diagnostics.Debug.WriteLine($"CSWebView: Received notification - {data}");
        }

        private void HandleData(object data)
        {
            // Handle data from web app
            System.Diagnostics.Debug.WriteLine($"CSWebView: Received data - {data}");
        }

        private void HandleCommand(object data)
        {
            // Handle commands from web app
            System.Diagnostics.Debug.WriteLine($"CSWebView: Received command - {data}");
        }

        // Method to reset communication service initialization
        public void ResetCommunicationService()
        {
            if (_communicationService != null)
            {
                _communicationService.Unregister();
                _isCommunicationServiceInitialized = false;
            }
        }

        // Cleanup method
        public void Cleanup()
        {
            if (_communicationService != null)
            {
                _communicationService.Unregister();
                _isCommunicationServiceInitialized = false;
            }
        }
    }
}
