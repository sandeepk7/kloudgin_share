using System.Windows;
using System.Windows.Input;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    public partial class ModalPopupWindow : Window
    {
        public ModalPopupWindow()
        {
            InitializeComponent();
            this.DataContext = this; // Set DataContext to itself for binding TitleText and PopupContent
            this.Loaded += ModalPopupWindow_Loaded;
            this.SizeChanged += ModalPopupWindow_SizeChanged;
            this.SourceInitialized += ModalPopupWindow_SourceInitialized;
        }

        public string TitleText
        {
            get { return (string)GetValue(TitleTextProperty); }
            set { SetValue(TitleTextProperty, value); }
        }

        public static readonly DependencyProperty TitleTextProperty =
            DependencyProperty.Register(
                "TitleText",
                typeof(string),
                typeof(ModalPopupWindow),
                new PropertyMetadata("", OnTitleTextChanged));

        private static void OnTitleTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is ModalPopupWindow window)
            {
                var newTitle = e.NewValue as string ?? string.Empty;
                window.Title = newTitle;
            }
        }

        public object? PopupContent
        {
            get { return (object?)GetValue(PopupContentProperty); }
            set { SetValue(PopupContentProperty, value); }
        }

        public static readonly DependencyProperty PopupContentProperty =
            DependencyProperty.Register("PopupContent", typeof(object), typeof(ModalPopupWindow), new PropertyMetadata(null));

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            // If shown via ShowDialog(), setting DialogResult closes the window.
            // If shown via Show(), DialogResult is invalid, so just Close().
            if (System.Windows.Interop.ComponentDispatcher.IsThreadModal)
            {
                this.DialogResult = true;
            }
            else
            {
                this.Close();
            }
        }

        private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MaximizeRestoreButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Maximized)
            {
                this.WindowState = WindowState.Normal;
            }
            else
            {
                this.WindowState = WindowState.Maximized;
            }
        }

        private void ModalPopupWindow_Loaded(object sender, RoutedEventArgs e)
        {
            ApplyWidthAndCenter();
        }

        private void ModalPopupWindow_SizeChanged(object? sender, SizeChangedEventArgs e)
        {
            // Keep centered when content changes height
            //CenterToOwner();
        }

        private void ModalPopupWindow_SourceInitialized(object? sender, System.EventArgs e)
        {
            // Apply width and center as early as possible
            ApplyWidthAndCenter();
        }

        private void ApplyWidthAndCenter()
        {
            if (this.Owner != null)
            {
                // Set width to 40% of owner, but cap it at a reasonable maximum (800px)
                var calculatedWidth = this.Owner.ActualWidth * 0.4;
                this.Width = double.IsNaN(this.Width) || this.Width == 0
                    ? Math.Max(400, Math.Min(800, calculatedWidth))
                    : this.Width;
                
                // Set height to 70% of owner, but cap it at a reasonable maximum (600px)
                var calculatedHeight = this.Owner.ActualHeight * 0.7;
                this.Height = double.IsNaN(this.Height) || this.Height == 0
                    ? Math.Max(400, Math.Min(600, calculatedHeight))
                    : this.Height;
                
                CenterToOwner();
            }
            else
            {
                // fallback to work area
                var wa = SystemParameters.WorkArea;
                var calculatedWidth = wa.Width * 0.4;
                this.Width = double.IsNaN(this.Width) || this.Width == 0
                    ? Math.Max(400, Math.Min(800, calculatedWidth))
                    : this.Width;
                
                var calculatedHeight = wa.Height * 0.7;
                this.Height = double.IsNaN(this.Height) || this.Height == 0
                    ? Math.Max(400, Math.Min(600, calculatedHeight))
                    : this.Height;
                
                this.Left = wa.Left + (wa.Width - this.Width) / 2;
                this.Top = wa.Top + (wa.Height - this.Height) / 2;
            }
        }

        private void CenterToOwner()
        {
            if (this.Owner != null)
            {
                var ownerPos = this.Owner.PointToScreen(new System.Windows.Point(0, 0));
                var ownerLeft = ownerPos.X / (PresentationSource.FromVisual(this.Owner)?.CompositionTarget?.TransformToDevice.M11 ?? 1.0);
                var ownerTop = ownerPos.Y / (PresentationSource.FromVisual(this.Owner)?.CompositionTarget?.TransformToDevice.M22 ?? 1.0);
                this.Left = ownerLeft + (this.Owner.ActualWidth - this.Width) / 2;
                this.Top = ownerTop + (this.Owner.ActualHeight - this.ActualHeight) / 2;
            }
        }
    }
}


