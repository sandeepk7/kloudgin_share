using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using CefSharp;
using CefSharp.Wpf;
using KGWin.WPF.Views;
using KGWin.WPF.ViewModels;
using System.Windows;

namespace KGWin.WPF.Services
{
    public class CommunicationService
    {
        private ChromiumWebBrowser? _browser;
        private readonly Dictionary<string, Action<object>> _eventHandlers;
        private Action<string, object>? _messageHandler;
        private Action<string>? _chatMessageHandler;
        private bool _isInitialized = false;
        private System.Windows.Threading.Dispatcher? _dispatcher;
        private readonly List<Window> _openPopups = new List<Window>();

        public event EventHandler<string>? MessageReceived;
        public event EventHandler<string>? ErrorOccurred;

        public CommunicationService()
        {
            _eventHandlers = new Dictionary<string, Action<object>>();
        }

        public void Initialize(ChromiumWebBrowser browser)
        {
            _browser = browser;
            _dispatcher = System.Windows.Application.Current.Dispatcher;

            // Log when bound
            browser.JavascriptObjectRepository.ObjectBoundInJavascript += (s, e) =>
            {
                if (e.ObjectName == "communicationService")
                {
                    _isInitialized = true;
                }
            };

            // Register once (don't double-register in ResolveObject)
            if (!browser.JavascriptObjectRepository.IsBound("communicationService"))
            {
                var jsObject = new CommunicationJsObject(this);
                browser.JavascriptObjectRepository.Register("communicationService", jsObject);
            }
        }


        public void Unregister()
        {
            if (_browser != null && _browser.JavascriptObjectRepository.IsBound("communicationService"))
            {
                _browser.JavascriptObjectRepository.UnRegister("communicationService");
                _isInitialized = false;
            }
        }

        public async Task SendMessageToWebApp(string messageType, object data)
        {
            if (_browser == null)
            {
                ErrorOccurred?.Invoke(this, "Browser not initialized");
                return;
            }

            if (!_browser.IsBrowserInitialized)
            {
                ErrorOccurred?.Invoke(this, "Browser not fully initialized");
                return;
            }

            if (!_browser.CanExecuteJavascriptInMainFrame)
            {
                ErrorOccurred?.Invoke(this, "Cannot execute JavaScript - V8 context not ready");
                return;
            }

            try
            {
                var jsonData = System.Text.Json.JsonSerializer.Serialize(data);
                var script = $"window.postMessage({{ type: '{messageType}', data: {jsonData} }}, '*');";

                await _browser.EvaluateScriptAsync(script);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"Error sending message: {ex.Message}");
            }
        }

        public async Task SendChatMessageToAngular(string messageText)
        {
            await SendMessageToWebApp("chat", messageText);
        }

        public async Task SendCommunicationMessageToAngular(string messageText)
        {
            await SendMessageToWebApp("communication", messageText);
        }

        public void RegisterEventHandler(string eventType, Action<object> handler)
        {
            _eventHandlers[eventType] = handler;
        }

        public void RegisterMessageHandler(Action<string, object> handler)
        {
            _messageHandler = handler;
        }

        public void RegisterChatMessageHandler(Action<string> handler)
        {
            _chatMessageHandler = handler;
        }

        public void HandleMessageFromWebApp(string messageType, object data)
        {
            MessageReceived?.Invoke(this, $"Received {messageType}: {data}");
            // Popup window state controls
            if (messageType == "minimizeLastPopup")
            {
                MinimizeLastPopup();
                return;
            }
            if (messageType == "maximizeLastPopup")
            {
                MaximizeLastPopup();
                return;
            }
            if (messageType == "restoreLastPopup")
            {
                RestoreLastPopup();
                return;
            }

            // Handle chat and communication messages specifically
            if ((messageType == "chat" || messageType == "communication") && data is string messageText)
            {
                _chatMessageHandler?.Invoke(messageText);
                return;
            }

            // Handle WPF map popup opening
            if (messageType == "openWpfMapPopup" && data is string popupDataJson)
            {
                HandleOpenWpfMapPopup(popupDataJson);
                return;
            }

            // Handle switch to WPF map
            if (messageType == "switchToWpfMap")
            {
                HandleSwitchToWpfMap();
                return;
            }

            // Handle general messages
            _messageHandler?.Invoke(messageType, data);

            if (_eventHandlers.TryGetValue(messageType, out var handler))
            {
                try
                {
                    handler(data);
                }
                catch (Exception ex)
                {
                    ErrorOccurred?.Invoke(this, $"Error handling message {messageType}: {ex.Message}");
                }
            }
        }

        private void HandleOpenWpfMapPopup(string popupDataJson)
        {
            try
            {
                // Parse the popup data JSON
                var popupData = System.Text.Json.JsonSerializer.Deserialize<dynamic>(popupDataJson);
                
                // Extract the required properties
                string title = popupData?.GetProperty("title").GetString() ?? "Unknown";
                string type = popupData?.GetProperty("type").GetString() ?? "Unknown";
                double longitude = popupData?.GetProperty("longitude").GetDouble() ?? 0.0;
                double latitude = popupData?.GetProperty("latitude").GetDouble() ?? 0.0;

                // Ensure we're on the UI thread before creating the window
                if (_dispatcher != null)
                {
                    _dispatcher.Invoke(() =>
                    {
                        // Check if this is a Naperville popup
                        if (type.ToLower() == "naperville")
                        {
                            // Create Naperville view
                            var napervilleView = new NapervilleView();
                            var napervilleViewModel = new NapervilleViewModel();
                            napervilleView.DataContext = napervilleViewModel;
                            
                            // Show using window-based popup (no backdrop)
                            var napervilleWindow = new Views.ModalPopupWindow
                            {
                                Owner = System.Windows.Application.Current.MainWindow,
                                TitleText = title,
                                PopupContent = napervilleView
                            };
                            // Fixed size and centered for Naperville popup
                            napervilleWindow.SizeToContent = System.Windows.SizeToContent.Manual;
                            napervilleWindow.Width = 1000;
                            napervilleWindow.Height = 500;
                            napervilleWindow.ResizeMode = System.Windows.ResizeMode.CanResize;
                            
                            // Use window defaults; sizing can be overridden by configuration below
                            
                            TrackAndShowPopup(napervilleWindow);
                        }
                        else
                        {
                            // Create generic map view
                            var mapView = new MapView();
                            var mapViewModel = new MapViewModel();
                            mapView.DataContext = mapViewModel;
                            
                            // Configure popup for generic map
                            // Optional configuration for future use; if needed, apply to mapWindow
                            var config = new ModalPopupConfig
                            {
                                Width = 1200,
                                Height = 700,
                                MinWidth = 1200,
                                MinHeight = 700,
                                ShowBackdrop = true,
                                CloseOnBackdropClick = true,
                                CloseOnEscape = true,
                                ShowHeader = true,
                                ShowCloseButton = true,
                                ShowFooter = false,
                                ResizeMode = System.Windows.ResizeMode.CanResize
                            };
                            
                            // Show generic map in window-based popup (no backdrop)
                            var mapWindow = new Views.ModalPopupWindow
                            {
                                Owner = System.Windows.Application.Current.MainWindow,
                                TitleText = title,
                                PopupContent = mapView
                            };
                            // Apply overrides if provided (example: using config)
                            if (config != null)
                            {
                                mapWindow.MinWidth = config.MinWidth;
                                mapWindow.MinHeight = config.MinHeight;
                                if (config.Width > 0) mapWindow.Width = config.Width;
                                if (config.Height > 0) mapWindow.Height = config.Height;
                                mapWindow.ResizeMode = config.ResizeMode;
                            }
                            TrackAndShowPopup(mapWindow);
                        }
                    });
                }
                else
                {
                    ErrorOccurred?.Invoke(this, "Dispatcher not available, cannot open WPF map popup");
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"Error opening WPF map popup: {ex.Message}");
            }
        }

        private void HandleSwitchToWpfMap()
        {
            try
            {
                // Ensure we're on the UI thread before switching to WPF map
                if (_dispatcher != null)
                {
                    _dispatcher.Invoke(() =>
                    {
                        // Get the main window and its view model
                        var mainWindow = System.Windows.Application.Current.MainWindow as MainWindow;
                        if (mainWindow != null && mainWindow.DataContext is ViewModels.MainViewModel mainViewModel)
                        {
                            // Use the existing navigation command to switch to map
                            mainViewModel.NavigateToMapCommand.Execute(null);
                            
                        }
                        else
                        {
                            ErrorOccurred?.Invoke(this, "Main window or MainViewModel not found, cannot switch to WPF map");
                        }
                    });
                }
                else
                {
                    ErrorOccurred?.Invoke(this, "Dispatcher not available, cannot switch to WPF map");
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"Error switching to WPF map: {ex.Message}");
            }
        }

        public async Task ExecuteJavaScript(string script)
        {
            if (_browser == null)
            {
                ErrorOccurred?.Invoke(this, "Browser not initialized");
                return;
            }

            if (!_browser.IsBrowserInitialized)
            {
                ErrorOccurred?.Invoke(this, "Browser not fully initialized");
                return;
            }

            if (!_browser.CanExecuteJavascriptInMainFrame)
            {
                ErrorOccurred?.Invoke(this, "Cannot execute JavaScript - V8 context not ready");
                return;
            }

            try
            {
                await _browser.EvaluateScriptAsync(script);
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke(this, $"Error executing JavaScript: {ex.Message}");
            }
        }

        public bool IsReady()
        {
            return _browser != null && 
                   _browser.IsBrowserInitialized && 
                   _browser.CanExecuteJavascriptInMainFrame && 
                   _isInitialized;
        }

        private void TrackAndShowPopup(Window popup)
        {
            _openPopups.Add(popup);
            popup.Closed += (s, e) =>
            {
                _openPopups.Remove(popup);
            };
            popup.Show();
        }

        public void MinimizeLastPopup()
        {
            if (_dispatcher == null) return;
            _dispatcher.Invoke(() =>
            {
                var win = _openPopups.Count > 0 ? _openPopups[^1] : null;
                if (win != null) win.WindowState = WindowState.Minimized;
            });
        }

        public void MaximizeLastPopup()
        {
            if (_dispatcher == null) return;
            _dispatcher.Invoke(() =>
            {
                var win = _openPopups.Count > 0 ? _openPopups[^1] : null;
                if (win != null) win.WindowState = WindowState.Maximized;
            });
        }

        public void RestoreLastPopup()
        {
            if (_dispatcher == null) return;
            _dispatcher.Invoke(() =>
            {
                var win = _openPopups.Count > 0 ? _openPopups[^1] : null;
                if (win != null) win.WindowState = WindowState.Normal;
            });
        }

        public void CloseAllPopups()
        {
            if (_dispatcher != null)
            {
                _dispatcher.Invoke(() =>
                {
                    foreach (var win in new List<Window>(_openPopups))
                    {
                        try { win.Close(); } catch { }
                    }
                    _openPopups.Clear();
                });
            }
        }
    }

    // JavaScript object that will be available in the web app
    public class CommunicationJsObject
    {
        private readonly CommunicationService _service;

        public CommunicationJsObject(CommunicationService service)
        {
            _service = service;
        }

        public void sendMessage(string messageType, object data)
        {
            _service.HandleMessageFromWebApp(messageType, data);
        }

        public void sendChatMessage(string messageText)
        {
            _service.HandleMessageFromWebApp("chat", messageText);
        }

        public void sendCommunicationMessage(string messageText)
        {
            _service.HandleMessageFromWebApp("communication", messageText);
        }

        public void sendNotification(string title, string message)
        {
            _service.HandleMessageFromWebApp("notification", new { title, message });
        }

        public void sendData(string dataType, object data)
        {
            _service.HandleMessageFromWebApp("data", new { dataType, data });
        }

        public void openWpfMapPopup(string popupDataJson)
        {
            _service.HandleMessageFromWebApp("openWpfMapPopup", popupDataJson);
        }

        public void switchToWpfMap()
        {
            _service.HandleMessageFromWebApp("switchToWpfMap", string.Empty);
        }

        public void minimizeLastPopup()
        {
            _service.HandleMessageFromWebApp("minimizeLastPopup", string.Empty);
        }

        public void maximizeLastPopup()
        {
            _service.HandleMessageFromWebApp("maximizeLastPopup", string.Empty);
        }

        public void restoreLastPopup()
        {
            _service.HandleMessageFromWebApp("restoreLastPopup", string.Empty);
        }

        public void closeAllPopups()
        {
            _service.CloseAllPopups();
        }
    }

    // Individual objects for global function registrations
    public class SendChatMessageObject
    {
        private readonly CommunicationService _service;

        public SendChatMessageObject(CommunicationService service)
        {
            _service = service;
        }

        public void SendChatMessage(string messageText)
        {
            _service.HandleMessageFromWebApp("chat", messageText);
        }
    }

    public class SendMessageObject
    {
        private readonly CommunicationService _service;

        public SendMessageObject(CommunicationService service)
        {
            _service = service;
        }

        public void SendMessage(string messageType, object data)
        {
            _service.HandleMessageFromWebApp(messageType, data);
        }
    }
}
