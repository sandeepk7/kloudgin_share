using Esri.ArcGISRuntime;
using Esri.ArcGISRuntime.Security;
using System.Windows;
using CefSharp;
using CefSharp.Wpf;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KGWin.WPF.Services;


namespace KGWin.WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private IConfiguration? _configuration;
        private ILogger<App>? _logger;
        private EsriMapService? _esriMapService;
        private CefSharpService? _cefSharpService;

        // Static property to access configuration from other parts of the application
        public static IConfiguration? Configuration { get; private set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var configService = new ConfigurationService();
            _configuration = configService.BuildConfiguration();
            Configuration = _configuration; // expose globally

            using var loggerFactory = configService.CreateLoggerFactory(_configuration);
            _logger = loggerFactory.CreateLogger<App>();
            InitializeEsriMap();
            InitializeCefSharp();
            
            // Handle command line arguments for URL protocol
            if (e.Args.Length > 0)
            {
                HandleUrlProtocol(e.Args[0]);
            }
        }

        private void InitializeConfiguration() { }
        private void InitializeLogging() { }

        private void InitializeEsriMap()
        {
            _esriMapService ??= new EsriMapService(_configuration!, _logger!);
            _esriMapService.Initialize();
        }

        private void InitializeCefSharp()
        {
            _cefSharpService ??= new CefSharpService(_configuration!, _logger!);
            _cefSharpService.Initialize();
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            _logger?.LogInformation("Application shutting down");
            _cefSharpService?.Shutdown();
        }

        private void HandleUrlProtocol(string url)
        {
            try
            {
                if (url.StartsWith("kgwin://"))
                {
                    var uri = new Uri(url);
                    var query = System.Web.HttpUtility.ParseQueryString(uri.Query);
                    var popupDataJson = query["popupData"];
                    
                    if (!string.IsNullOrEmpty(popupDataJson))
                    {
                        // Decode the URL-encoded JSON
                        var decodedJson = System.Web.HttpUtility.UrlDecode(popupDataJson);
                        
                        // Deserialize the popup data
                        var popupData = System.Text.Json.JsonSerializer.Deserialize<dynamic>(decodedJson);
                        
                        // Store the popup data for the main window to access
                        Current.Properties["PopupDataFromWeb"] = popupData;
                        
                        _logger?.LogInformation("Received popup data from web: {PopupData}", decodedJson);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Error handling URL protocol");
            }
        }
    }
}
