using System.Collections.ObjectModel;
using System.Windows.Input;
using KGWin.WPF.ViewModels.Base;
using Microsoft.Extensions.Configuration;

namespace KGWin.WPF.ViewModels
{
    public class InteractiveTextItem : ViewModelBase
    {
        private string _text = string.Empty;
        private bool _isSelected;

        public string Text
        {
            get => _text;
            set => SetProperty(ref _text, value);
        }

        public bool IsSelected
        {
            get => _isSelected;
            set => SetProperty(ref _isSelected, value);
        }

        public ICommand ToggleSelectionCommand { get; private set; }

        public InteractiveTextItem(string text)
        {
            Text = text;
            ToggleSelectionCommand = new RelayCommand(ToggleSelection);
        }

        private void ToggleSelection()
        {
            IsSelected = !IsSelected;
        }
    }

    public class HomeViewModel : ViewModelBase
    {
        public string WelcomeMessage { get; set; } = "Welcome to KGWin Application!";
        public string Description { get; set; } = "Use the below text input to open the desired page.";
        private string _userInput = App.Configuration?["Browser:Address"] ?? "http://localhost:4200";
        public string UserInput 
        { 
            get => _userInput; 
            set => SetProperty(ref _userInput, value); 
        }

        public ObservableCollection<InteractiveTextItem> InteractiveTextItems { get; private set; } = new();
        public ObservableCollection<InteractiveTextItem> CommunicationItems { get; private set; } = new();

        public ICommand OpenLocalhostCommand { get; private set; }
        public ICommand OpenKloudGinCommand { get; private set; }
        public ICommand OpenGoogleCommand { get; private set; }
        public ICommand OpenMicrosoftCommand { get; private set; }

        public HomeViewModel()
        {
            OpenLocalhostCommand = new RelayCommand(OpenLocalhost);
            OpenKloudGinCommand = new RelayCommand(OpenKloudGin);
            OpenGoogleCommand = new RelayCommand(OpenGoogle);
            OpenMicrosoftCommand = new RelayCommand(OpenMicrosoft);
            InitializeInteractiveTextItems();
            InitializeCommunicationItems();
        }

        private void InitializeInteractiveTextItems()
        {
            InteractiveTextItems = new ObservableCollection<InteractiveTextItem>
            {
                new InteractiveTextItem("Check different URLs"),
                new InteractiveTextItem("Check whether the Esri map is working in CefSharp")                
            };
        }

        private void InitializeCommunicationItems()
        {
            CommunicationItems = new ObservableCollection<InteractiveTextItem>
            {
                new InteractiveTextItem("Connect Web Page to WPF"),
                new InteractiveTextItem("Send plain text (greetings) messages"),
                new InteractiveTextItem("Send JSON messages"),
                new InteractiveTextItem("Show Assets"),
                new InteractiveTextItem("Show Markers"),
            };
        }

        private void OpenLocalhost()
        {
            // Use configured address or default to localhost:4200
            var configuredAddress = App.Configuration?["Browser:Address"] ?? "http://localhost:4200";
            UserInput = configuredAddress;
            // Trigger navigation to web page
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                if (System.Windows.Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel)
                {
                    mainViewModel.NavigateToWebCommand.Execute(null);
                }
            });
        }

        private void OpenKloudGin()
        {
            UserInput = "https://kloudgin.com";
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                if (System.Windows.Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel)
                {
                    mainViewModel.NavigateToWebCommand.Execute(null);
                }
            });
        }

        private void OpenGoogle()
        {
            UserInput = "https://www.google.com";
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                if (System.Windows.Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel)
                {
                    mainViewModel.NavigateToWebCommand.Execute(null);
                }
            });
        }

        private void OpenMicrosoft()
        {
            UserInput = "https://www.microsoft.com";
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                if (System.Windows.Application.Current.MainWindow?.DataContext is MainViewModel mainViewModel)
                {
                    mainViewModel.NavigateToWebCommand.Execute(null);
                }
            });
        }
    }
}

