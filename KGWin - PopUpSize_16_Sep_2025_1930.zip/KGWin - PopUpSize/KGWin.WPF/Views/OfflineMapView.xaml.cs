using System.Windows.Controls;
using Esri.ArcGISRuntime.UI;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    public partial class OfflineMapView : UserControl
    {
        private bool _overlaysInitialized = false;

        public OfflineMapView()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, System.Windows.RoutedEventArgs e)
        {
            if (DataContext is MapViewModel vm && !_overlaysInitialized)
            {
                try
                {
                    // Clear any existing overlays first to avoid conflicts
                    if (MapViewControl != null)
                    {
                        var mapViewControl = MapViewControl;
                        mapViewControl.GraphicsOverlays.Clear();
                        
                        // Add the overlays from the ViewModel
                        mapViewControl.GraphicsOverlays.Add(vm.AssetsOverlay);
                        mapViewControl.GraphicsOverlays.Add(vm.MarkersOverlay);
                        
                        // Add click event handler
                        mapViewControl.GeoViewTapped += MapViewControl_GeoViewTapped;
                    }
                    
                    _overlaysInitialized = true;
                    System.Diagnostics.Debug.WriteLine("OfflineMapView: Graphics overlays initialized successfully");
                }
                catch (System.Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"OfflineMapView: Error initializing overlays: {ex.Message}");
                }
            }
        }

        private void MapViewControl_GeoViewTapped(object? sender, Esri.ArcGISRuntime.UI.Controls.GeoViewInputEventArgs e)
        {
            if (DataContext is MapViewModel vm)
            {
                // Get the tapped position
                var tappedPosition = e.Position;
                
                // Identify graphics at the tapped location
                var identifyResults = MapViewControl.IdentifyGraphicsOverlaysAsync(tappedPosition, 10, false);
                identifyResults.ContinueWith(task =>
                {
                    if (task.Result.Count > 0)
                    {
                        var result = task.Result[0];
                        if (result.Graphics.Count > 0)
                        {
                            var graphic = result.Graphics[0];
                            
                            // Use Dispatcher to update UI from background thread
                            System.Windows.Application.Current.Dispatcher.Invoke(() =>
                            {
                                vm.HandleGraphicClick(graphic);
                            });
                        }
                    }
                });
            }
        }
    }
}
