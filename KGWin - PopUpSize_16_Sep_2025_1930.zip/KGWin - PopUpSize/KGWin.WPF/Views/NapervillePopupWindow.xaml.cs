using System;
using System.Windows;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for NapervillePopupWindow.xaml
    /// </summary>
    public partial class NapervillePopupWindow : Window
    {
        private NapervilleViewModel? _viewModel;

        public NapervillePopupWindow()
        {
            InitializeComponent();
            InitializeViewModel();
        }

        public NapervillePopupWindow(string title, string type, double longitude, double latitude) : this()
        {
            Title = title;
            // The NapervilleViewModel will handle the map initialization with Naperville data
        }

        private void InitializeViewModel()
        {
            _viewModel = new NapervilleViewModel();
            DataContext = _viewModel;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            // Clean up resources
            if (_viewModel != null)
            {
                // Dispose of the view model if needed
                _viewModel = null!;
            }
            base.OnClosed(e);
        }
    }
}
