using System.Windows.Controls;
using Esri.ArcGISRuntime.UI.Controls;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for NapervilleView.xaml
    /// </summary>
    public partial class NapervilleView : UserControl
    {
        public NapervilleView()
        {
            InitializeComponent();
        }

        private async void MapView_GeoViewTapped(object sender, GeoViewInputEventArgs e)
        {
            if (DataContext is NapervilleViewModel viewModel)
            {
                await viewModel.HandleMapClick(NapervilleMapView, e);
            }
        }
    }
}
