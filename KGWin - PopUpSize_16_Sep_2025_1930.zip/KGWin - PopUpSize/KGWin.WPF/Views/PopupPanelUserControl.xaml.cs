using System.Windows;
using System.Windows.Controls;

namespace KGWin.WPF.Views
{
    public partial class PopupPanelUserControl : UserControl
    {
        public PopupPanelUserControl()
        {
            InitializeComponent();
        }

        public void Show()
        {
            this.Visibility = Visibility.Visible;
        }

        public void Hide()
        {
            this.Visibility = Visibility.Collapsed;
        }
    }
}


