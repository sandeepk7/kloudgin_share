﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using KGWin.WPF.Services;
using Microsoft.Extensions.Configuration;

namespace KGWin.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ViewModels.MainViewModel _mainViewModel;

        public MainWindow()
        {
            InitializeComponent();
            _mainViewModel = new ViewModels.MainViewModel(App.Configuration);
            DataContext = _mainViewModel;
            
            // Connect the CommunicationViewModel to the MainViewModel
            if (_mainViewModel.CommunicationViewModel != null)
            {
                _mainViewModel.CommunicationViewModel.MainViewModel = _mainViewModel;
            }
            
            // Register the modal overlay with the service
            ModalPopupService.Instance.SetModalOverlay(ModalOverlay);
            
            // Check for popup data from web application
            Loaded += MainWindow_Loaded;
        }

        private void CSWebView_Loaded(object sender, RoutedEventArgs e)
        {
            // Connect the CSWebView to the MainViewModel
            if (sender is Views.CSWebView csWebView)
            {
                _mainViewModel.CSWebView = csWebView;
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Check if there's popup data from the web application
            if (App.Current.Properties.Contains("PopupDataFromWeb"))
            {
                var popupData = App.Current.Properties["PopupDataFromWeb"];
                if (popupData != null)
                {
                    // Show the popup with the data from web
                    ShowPopupFromWeb(popupData);
                    
                    // Clear the data from app properties
                    App.Current.Properties.Remove("PopupDataFromWeb");
                }
            }
        }

        private void ShowPopupFromWeb(dynamic popupData)
        {
            try
            {
                // Extract the popup data
                string id = popupData.GetProperty("id").GetString() ?? "Unknown";
                string type = popupData.GetProperty("type").GetString() ?? "Unknown";
                string title = popupData.GetProperty("title").GetString() ?? "Unknown";
                string color = popupData.GetProperty("color").GetString() ?? "Unknown";
                string longitude = popupData.GetProperty("longitude").GetString() ?? "Unknown";
                string latitude = popupData.GetProperty("latitude").GetString() ?? "Unknown";
                string description = popupData.GetProperty("description").GetString() ?? "";
                string status = popupData.GetProperty("status").GetString() ?? "Active";
                string notes = popupData.GetProperty("notes").GetString() ?? "";

                // Parse coordinates
                if (double.TryParse(longitude, out double lon) && double.TryParse(latitude, out double lat))
                {
                    // Create and show the WPF map popup window
                    var mapPopupWindow = new Views.MapPopupWindow(title, type, lon, lat);
                    mapPopupWindow.Show();
                    
                    System.Diagnostics.Debug.WriteLine($"Opened WPF map popup from web for {type}: {title} at {lon}, {lat}");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"Invalid coordinates: {longitude}, {latitude}");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error showing popup from web: {ex.Message}");
            }
        }
    }
}
