# KGWin.MSI Configuration Guide

## Step-by-Step Configuration Instructions

### 1. Add Project Output to Installer

1. **Open the KGWin.MSI project** in Visual Studio
2. **Right-click on "KGWin.MSI"** in Solution Explorer
3. **Select "Add" → "Project Output..."**
4. **In the "Add Project Output Group" dialog:**
   - **Project**: Select "KGWin.WPF"
   - **Configuration**: Select "Active" or "Release"
   - **Check "Primary output"** from the list
   - **Click "OK"**

### 2. Configure Installer Properties

1. **Right-click on "KGWin.MSI"** project in Solution Explorer
2. **Select "Properties"** (this opens the Property Pages dialog you're seeing)
3. **In the Property Pages dialog:**
   - **Output file name**: Keep as `Debug\KGWin.msi` (or `Release\KGWin.msi` for Release)
   - **Package files**: Set to "In setup file"
   - **Compression**: Set to "Optimized for speed"
   - **CAB size**: Leave as "Unlimited"
4. **Click "Prerequisites..." button** to configure prerequisites
5. **For additional properties, you need to access the Setup Project editor:**
   - **Right-click on "KGWin.MSI"** project
   - **Select "View" → "Properties"** (this opens the Setup Project Properties)
   - **Set the following properties:**

   | Property | Value |
   |----------|-------|
   | **Product Name** | `KGWin Application` |
   | **Manufacturer** | `KloudGin` |
   | **Version** | `1.0.0` |
   | **Title** | `KGWin Application Installer` |
   | **Description** | `Installer for KGWin Application` |
   | **Author** | `KloudGin` |
   | **Keywords** | `KGWin, KloudGin, WPF, Application` |

### 3. Configure Installation Folder

1. **Right-click on "KGWin.MSI"** project
2. **Select "View" → "File System"**
3. **In the File System editor:**
   - **Right-click on "Application Folder"**
   - **Select "Properties"**
   - **Set "DefaultLocation"** to: `[ProgramFilesFolder]KloudGin\KGWin`

### 4. Add Desktop Shortcut

1. **In the File System editor:**
   - **Right-click on "User's Desktop"**
   - **Select "Create New Shortcut"**
   - **Browse to**: "Application Folder" → "Primary output from KGWin.WPF"
   - **Name**: `KGWin Application`
   - **Click "OK"**

### 5. Add Start Menu Shortcut

1. **In the File System editor:**
   - **Right-click on "User's Programs Menu"**
   - **Select "Create New Shortcut"**
   - **Browse to**: "Application Folder" → "Primary output from KGWin.WPF"
   - **Name**: `KGWin Application`
   - **Click "OK"**

### 6. Configure Prerequisites (Important!)

1. **Right-click on "KGWin.MSI"** project
2. **Select "Properties"**
3. **Go to "Prerequisites" tab**
4. **Check the following:**
   - ✅ **.NET Desktop Runtime 8.0** (or higher)
   - ✅ **Microsoft Visual C++ 2015-2022 Redistributable (x64)**
   - ✅ **Windows Installer 3.1**

### 7. Add Additional Files (if needed)

If you need to include additional files:

1. **In the File System editor:**
   - **Right-click on "Application Folder"**
   - **Select "Add" → "File..."**
   - **Browse and select files** (e.g., configuration files, data files)
   - **Click "OK"**

### 8. Configure Custom Actions (Optional)

For advanced configuration:

1. **Right-click on "KGWin.MSI"** project
2. **Select "View" → "Custom Actions"**
3. **Add custom actions** if needed (e.g., registry entries, service installation)

### 9. Build Configuration

1. **Set the solution configuration** to "Release"
2. **Right-click on "KGWin.MSI"** project
3. **Select "Build"**
4. **The MSI file will be created** in: `KGWin.MSI\bin\Release\KGWin.MSI.msi`

## Verification Checklist

- [ ] Project output added (Primary output from KGWin.WPF)
- [ ] Installer properties configured
- [ ] Installation folder set to Program Files
- [ ] Desktop shortcut created
- [ ] Start menu shortcut created
- [ ] Prerequisites configured (.NET 8.0, VC++ Redistributable)
- [ ] Build successful
- [ ] MSI file generated

## Testing the Installer

1. **Navigate to**: `KGWin.MSI\bin\Release\`
2. **Run**: `KGWin.MSI.msi`
3. **Follow the installation wizard**
4. **Verify**:
   - Application installs correctly
   - Shortcuts are created
   - Application launches from shortcuts
   - Application appears in Programs & Features

## Troubleshooting

### Common Issues:

1. **Missing Dependencies**: Ensure all prerequisites are checked
2. **Build Errors**: Make sure KGWin.WPF builds successfully first
3. **File Not Found**: Verify project output is added correctly
4. **Permission Issues**: Run Visual Studio as Administrator if needed

### Build Order:
1. Build KGWin.WPF project first
2. Then build KGWin.MSI project

## Output Location

The final MSI installer will be located at:
```
KGWin.MSI\bin\Release\KGWin.MSI.msi
```

This file can be distributed to end users for installation.
