using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.Geometry;
using KGWin.WPF.Services;
using KGWin.WPF.ViewModels.Base;

namespace KGWin.WPF.ViewModels
{
    public class LayerItem : ViewModelBase
    {
        private bool _isVisible = true;
        private string _name = "";
        private string _layerType = "";
        private string _description = "";
        private string _fullExtent = "";
        private string _minScale = "";
        private string _maxScale = "";
        private string _itemId = "";
        private string _url = "";
        private string _popupTitle = "";
        private string _popupFields = "";
        private bool _hasPopupDefinition = false;

        public bool IsVisible
        {
            get => _isVisible;
            set => SetProperty(ref _isVisible, value);
        }

        public string Name
        {
            get => _name;
            set => SetProperty(ref _name, value);
        }

        public string LayerType
        {
            get => _layerType;
            set => SetProperty(ref _layerType, value);
        }

        public string Description
        {
            get => _description;
            set => SetProperty(ref _description, value);
        }

        public string FullExtent
        {
            get => _fullExtent;
            set => SetProperty(ref _fullExtent, value);
        }

        public string MinScale
        {
            get => _minScale;
            set => SetProperty(ref _minScale, value);
        }

        public string MaxScale
        {
            get => _maxScale;
            set => SetProperty(ref _maxScale, value);
        }

        public string ItemId
        {
            get => _itemId;
            set => SetProperty(ref _itemId, value);
        }

        public string Url
        {
            get => _url;
            set => SetProperty(ref _url, value);
        }

        public string PopupTitle
        {
            get => _popupTitle;
            set => SetProperty(ref _popupTitle, value);
        }

        public string PopupFields
        {
            get => _popupFields;
            set => SetProperty(ref _popupFields, value);
        }

        public bool HasPopupDefinition
        {
            get => _hasPopupDefinition;
            set => SetProperty(ref _hasPopupDefinition, value);
        }

        public Layer? Layer { get; set; }
    }

    public class NapervilleViewModel : ViewModelBase
    {
        public class FieldRow : ViewModelBase
        {
            private string _label = "";
            public string Label
            {
                get => _label;
                set => SetProperty(ref _label, value);
            }

            private string _value = "";
            public string Value
            {
                get => _value;
                set => SetProperty(ref _value, value);
            }
        }

        private ObservableCollection<FieldRow> _popupRows = new ObservableCollection<FieldRow>();
        public ObservableCollection<FieldRow> PopupRows
        {
            get => _popupRows;
            set => SetProperty(ref _popupRows, value);
        }
        private string _welcomeMessage = "Welcome to Naperville!";
        public string WelcomeMessage
        {
            get => _welcomeMessage;
            set => SetProperty(ref _welcomeMessage, value);
        }

        private string _description = "This is the Naperville section of the application. Here you can explore Naperville-specific features and data.";
        public string Description
        {
            get => _description;
            set => SetProperty(ref _description, value);
        }

        private Map _napervilleMap = null!;
        public Map NapervilleMap
        {
            get => _napervilleMap;
            set => SetProperty(ref _napervilleMap, value);
        }

        private string _mapStatus = "Map not loaded";
        public string MapStatus
        {
            get => _mapStatus;
            set => SetProperty(ref _mapStatus, value);
        }

        private ObservableCollection<LayerItem> _layers = new ObservableCollection<LayerItem>();
        public ObservableCollection<LayerItem> Layers
        {
            get => _layers;
            set => SetProperty(ref _layers, value);
        }

        // Popup properties
        private bool _isPopupVisible = false;
        public bool IsPopupVisible
        {
            get => _isPopupVisible;
            set => SetProperty(ref _isPopupVisible, value);
        }

        private string _popupTitle = "";
        public string PopupTitle
        {
            get => _popupTitle;
            set => SetProperty(ref _popupTitle, value);
        }

        private string _popupContent = "";
        public string PopupContent
        {
            get => _popupContent;
            set => SetProperty(ref _popupContent, value);
        }

        // Strongly-typed popup fields for display (label left, value right)
        private string _popupAssetId = "";
        public string PopupAssetId
        {
            get => _popupAssetId;
            set => SetProperty(ref _popupAssetId, value);
        }

        private string _popupComments = "";
        public string PopupComments
        {
            get => _popupComments;
            set => SetProperty(ref _popupComments, value);
        }

        private string _popupLocation = "";
        public string PopupLocation
        {
            get => _popupLocation;
            set => SetProperty(ref _popupLocation, value);
        }

        private string _popupStatus = "";
        public string PopupStatus
        {
            get => _popupStatus;
            set => SetProperty(ref _popupStatus, value);
        }

        private string _popupType = "";
        public string PopupType
        {
            get => _popupType;
            set => SetProperty(ref _popupType, value);
        }

        private string _popupLastUpdated = "";
        public string PopupLastUpdated
        {
            get => _popupLastUpdated;
            set => SetProperty(ref _popupLastUpdated, value);
        }

        private string _popupLayerName = "";
        public string PopupLayerName
        {
            get => _popupLayerName;
            set => SetProperty(ref _popupLayerName, value);
        }

        private double _popupX = 0;
        public double PopupX
        {
            get => _popupX;
            set => SetProperty(ref _popupX, value);
        }

        private double _popupY = 0;
        public double PopupY
        {
            get => _popupY;
            set => SetProperty(ref _popupY, value);
        }

        private string _workOrderUrl = "";
        public string WorkOrderUrl
        {
            get => _workOrderUrl;
            set => SetProperty(ref _workOrderUrl, value);
        }

        private string _selectedFeatureData = "";
        public string SelectedFeatureData
        {
            get => _selectedFeatureData;
            set => SetProperty(ref _selectedFeatureData, value);
        }

        // Commands
        public ICommand LoadVtpkCommand { get; private set; } = null!;
        public ICommand LoadMmpkCommand { get; private set; } = null!;
        public ICommand ClosePopupCommand { get; private set; } = null!;
        public ICommand CreateWorkOrderCommand { get; private set; } = null!;

        public NapervilleViewModel()
        {
            InitializeMap();
            InitializeCommands();
            LoadUtilityLayersByDefault();
        }

        private void InitializeMap()
        {
            // Initialize with Naperville basemap by default
            _napervilleMap = new Map(SpatialReferences.WebMercator)
            {
                Basemap = new Basemap(BasemapStyle.ArcGISTopographic),
                InitialViewpoint = new Viewpoint(
                    new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                    50000 // Zoom level to show Naperville area
                )
            };
            
            // Set initial status
            MapStatus = "Naperville basemap loaded - click 'Load NapervilleGas.mmpk' to add utility layers";
        }

        private void InitializeCommands()
        {
            LoadVtpkCommand = new RelayCommand(LoadVtpk);
            LoadMmpkCommand = new RelayCommand(LoadMmpk);
            ClosePopupCommand = new RelayCommand(ClosePopup);
            CreateWorkOrderCommand = new RelayCommand(CreateWorkOrder);
        }

        private async void LoadUtilityLayersByDefault()
        {
            try
            {
                // First, try to load utility layers from MMPK
                string mmpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "NapervilleGas.mmpk");

                if (System.IO.File.Exists(mmpkPath))
                {
                    try
                    {
                        System.Diagnostics.Debug.WriteLine($"Loading MMPK from: {mmpkPath}");

                // Load the MMPK file using ArcGIS Runtime APIs
                        System.Diagnostics.Debug.WriteLine($"Attempting to open MMPK file: {mmpkPath}");
                var mmpk = await Esri.ArcGISRuntime.Mapping.MobileMapPackage.OpenAsync(mmpkPath);
                        System.Diagnostics.Debug.WriteLine($"MMPK opened successfully");
                
                if (mmpk.Maps.Count > 0)
                {
                            System.Diagnostics.Debug.WriteLine($"MMPK loaded successfully, {mmpk.Maps.Count} maps found");
                            
                    // Get the first map from the MMPK
                    var mobileMap = mmpk.Maps[0];
                    
                            // Try to load VTPK as basemap first
                            await TryLoadVtpkAsBasemap(mobileMap);
                    
                    // Set initial viewpoint for Naperville
                    mobileMap.InitialViewpoint = new Viewpoint(
                        new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                        50000 // Zoom level
                    );
                    
                    // Replace the current map with the mobile map
                    NapervilleMap = mobileMap;
                    
                    // Add layers to the layer list for UI control
                    if (mobileMap.OperationalLayers != null)
                    {
                                System.Diagnostics.Debug.WriteLine($"Adding {mobileMap.OperationalLayers.Count} operational layers");
                                
                        foreach (var layer in mobileMap.OperationalLayers)
                        {
                                    System.Diagnostics.Debug.WriteLine($"Processing layer: {layer.Name} (Type: {layer.GetType().Name})");
                                    
                            var layerItem = ExtractLayerMetadata(layer);
                            
                            // Subscribe to visibility changes
                            layerItem.PropertyChanged += (s, e) =>
                            {
                                if (e.PropertyName == nameof(LayerItem.IsVisible))
                                {
                                    layer.IsVisible = layerItem.IsVisible;
                                }
                            };
                            
                            Layers.Add(layerItem);
                                    System.Diagnostics.Debug.WriteLine($"Added layer to UI: {layer.Name} (Visible: {layer.IsVisible})");
                        }
                    }
                            else
                            {
                                System.Diagnostics.Debug.WriteLine("No operational layers found in mobile map");
                    }
                    
                            MapStatus = $"Naperville map loaded with {Layers.Count} utility layers";
                    
                    // Log summary of all layers
                    LogLayerSummary();
                    
                    System.Diagnostics.Debug.WriteLine($"Utility layers loaded by default from: {mmpkPath}");
                        }
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("MMPK loaded but no maps found");
                            MapStatus = "MMPK loaded but no maps found";
                        }
                    }
                    catch (Exception mmpkEx)
                    {
                        System.Diagnostics.Debug.WriteLine($"Error loading MMPK: {mmpkEx.Message}");
                        System.Diagnostics.Debug.WriteLine($"Stack trace: {mmpkEx.StackTrace}");
                        MapStatus = $"Error loading MMPK: {mmpkEx.Message}";
                    }
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"MMPK file not found at: {mmpkPath}");
                    MapStatus = "MMPK file not found - using default map";
                }
            }
            catch (Exception ex)
            {
                MapStatus = "Error loading utility layers - using fallback map";
                System.Diagnostics.Debug.WriteLine($"Error loading utility layers by default: {ex}");
            }
        }

        private async Task LoadVtpkAsync()
        {
            try
            {
                MapStatus = "Loading Naperville VTPK...";
                
                // Get the path to the VTPK file in the Data folder
                string vtpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "Naperville.vtpk");

                if (!System.IO.File.Exists(vtpkPath))
                {
                    MapStatus = $"VTPK file not found at: {vtpkPath}";
                    System.Diagnostics.Debug.WriteLine($"VTPK file not found at: {vtpkPath}");
                    return;
                }

                // Try to load VTPK using VectorTileLayer
                try
                {
                    // Create a VectorTileLayer from the VTPK file
                    var vtpkUri = new Uri(vtpkPath);
                    var vectorTileLayer = new Esri.ArcGISRuntime.Mapping.ArcGISVectorTiledLayer(vtpkUri);
                    
                    // Wait for the layer to load
                    await vectorTileLayer.LoadAsync();
                    
                    // Create a new map with the VTPK as basemap
                var napervilleMap = new Map(SpatialReferences.WebMercator)
                {
                        Basemap = new Basemap(vectorTileLayer),
                    InitialViewpoint = new Viewpoint(
                        new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                        50000 // Zoom level
                    )
                };
                
                // Replace the current map
                NapervilleMap = napervilleMap;
                
                    MapStatus = "Naperville VTPK loaded successfully";
                    
                    System.Diagnostics.Debug.WriteLine($"Naperville VTPK loaded successfully from: {vtpkPath}");
                }
                catch (Exception vtpkEx)
                {
                    System.Diagnostics.Debug.WriteLine($"VTPK loading failed: {vtpkEx.Message}");
                    
                    // Fallback: Use a local basemap approach
                    var napervilleMap = new Map(SpatialReferences.WebMercator)
                    {
                        // Use a basemap that works well offline
                        Basemap = new Basemap(BasemapStyle.ArcGISLightGray),
                        InitialViewpoint = new Viewpoint(
                            new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                            50000 // Zoom level
                        )
                    };
                    
                    // Replace the current map
                    NapervilleMap = napervilleMap;
                    
                    MapStatus = "Naperville map loaded (VTPK fallback - using offline basemap)";
                    
                    System.Diagnostics.Debug.WriteLine($"Naperville map loaded with VTPK fallback from: {vtpkPath}");
                }
            }
            catch (Exception ex)
            {
                MapStatus = $"Error loading VTPK: {ex.Message}";
                System.Diagnostics.Debug.WriteLine($"Error loading VTPK: {ex}");
            }
        }

        private void LoadVtpk()
        {
            // Call the async method
            _ = LoadVtpkAsync();
        }

        private async Task TryLoadVtpkAsBasemap(Map map)
        {
            try
            {
                // Get the path to the VTPK file in the Data folder
                string vtpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "Naperville.vtpk");

                if (System.IO.File.Exists(vtpkPath))
                {
                    System.Diagnostics.Debug.WriteLine($"Attempting to load VTPK as basemap from: {vtpkPath}");
                    
                    // Create a VectorTileLayer from the VTPK file
                    var vtpkUri = new Uri(vtpkPath);
                    var vectorTileLayer = new Esri.ArcGISRuntime.Mapping.ArcGISVectorTiledLayer(vtpkUri);
                    
                    // Wait for the layer to load
                    await vectorTileLayer.LoadAsync();
                    
                    // Set the VTPK as the basemap
                    map.Basemap = new Basemap(vectorTileLayer);
                    
                    System.Diagnostics.Debug.WriteLine("VTPK loaded successfully as basemap");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine($"VTPK file not found at: {vtpkPath}, using default basemap");
                    // Use default basemap if VTPK not found
                    map.Basemap = new Basemap(BasemapStyle.ArcGISTopographic);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading VTPK as basemap: {ex.Message}");
                // Fallback to default basemap
                map.Basemap = new Basemap(BasemapStyle.ArcGISTopographic);
            }
        }

        private async void LoadMmpk()
        {
            try
            {
                MapStatus = "Reloading NapervilleGas.mmpk...";
                
                // Clear existing layers
                Layers.Clear();
                
                // Get the path to the MMPK file in the Data folder
                string mmpkPath = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory, 
                    "Data", 
                    "NapervilleGas.mmpk");

                if (!System.IO.File.Exists(mmpkPath))
                {
                    MapStatus = $"MMPK file not found at: {mmpkPath}";
                    System.Windows.MessageBox.Show(
                        $"MMPK file not found at: {mmpkPath}", 
                        "File Not Found", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Warning);
                    return;
                }

                // Load the MMPK file using ArcGIS Runtime APIs
                var mmpk = await Esri.ArcGISRuntime.Mapping.MobileMapPackage.OpenAsync(mmpkPath);
                
                if (mmpk.Maps.Count > 0)
                {
                    // Get the first map from the MMPK
                    var mobileMap = mmpk.Maps[0];
                    
                    // Set the basemap to Naperville topographic
                    mobileMap.Basemap = new Basemap(BasemapStyle.ArcGISTopographic);
                    
                    // Set initial viewpoint for Naperville
                    mobileMap.InitialViewpoint = new Viewpoint(
                        new MapPoint(-88.1473, 41.7508, SpatialReferences.Wgs84), // Naperville coordinates
                        50000 // Zoom level
                    );
                    
                    // Replace the current map with the mobile map
                    NapervilleMap = mobileMap;
                    
                    // Add layers to the layer list for UI control
                    if (mobileMap.OperationalLayers != null)
                    {
                        foreach (var layer in mobileMap.OperationalLayers)
                        {
                            var layerItem = ExtractLayerMetadata(layer);
                            
                            // Subscribe to visibility changes
                            layerItem.PropertyChanged += (s, e) =>
                            {
                                if (e.PropertyName == nameof(LayerItem.IsVisible))
                                {
                                    layer.IsVisible = layerItem.IsVisible;
                                }
                            };
                            
                            Layers.Add(layerItem);
                        }
                    }
                    
                    MapStatus = $"NapervilleGas.mmpk reloaded successfully! {Layers.Count} utility layers available.";
                    
                    System.Windows.MessageBox.Show(
                        $"NapervilleGas.mmpk reloaded successfully!\n\n{Layers.Count} utility layers are now available.\nUse the layer list on the left to toggle layer visibility.", 
                        "Success", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Information);
                    
                    System.Diagnostics.Debug.WriteLine($"NapervilleGas.mmpk reloaded successfully from: {mmpkPath}");
                }
                else
                {
                    MapStatus = "MMPK file loaded but no maps found";
                    System.Windows.MessageBox.Show(
                        "MMPK file loaded but no maps found.", 
                        "Warning", 
                        System.Windows.MessageBoxButton.OK, 
                        System.Windows.MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MapStatus = $"Error loading MMPK: {ex.Message}";
                System.Windows.MessageBox.Show(
                    $"Error loading MMPK file: {ex.Message}", 
                    "Error", 
                    System.Windows.MessageBoxButton.OK, 
                    System.Windows.MessageBoxImage.Error);
                
                System.Diagnostics.Debug.WriteLine($"Error loading MMPK: {ex}");
            }
        }

        private LayerItem ExtractLayerMetadata(Layer layer)
        {
            var layerItem = new LayerItem
            {
                Name = layer.Name ?? "Unnamed Layer",
                LayerType = GetLayerTypeName(layer),
                Layer = layer,
                IsVisible = layer.IsVisible
            };

            try
            {
                // Extract basic metadata
                layerItem.Description = layer.Description ?? "No description available";
                
                // Extract extent information
                if (layer.FullExtent != null)
                {
                    var extent = layer.FullExtent;
                    layerItem.FullExtent = $"X: {extent.XMin:F2} to {extent.XMax:F2}, Y: {extent.YMin:F2} to {extent.YMax:F2}";
                }
                else
                {
                    layerItem.FullExtent = "No extent information";
                }

                // Extract scale information
                layerItem.MinScale = layer.MinScale.ToString("N0");
                layerItem.MaxScale = layer.MaxScale.ToString("N0");

                // Extract popup definition information
                ExtractPopupDefinition(layer, layerItem);

                // Try to extract additional metadata based on layer type
                if (layer is Esri.ArcGISRuntime.Mapping.ArcGISMapImageLayer mapImageLayer)
                {
                    layerItem.Url = mapImageLayer.Source?.ToString() ?? "No URL available";
                    layerItem.ItemId = mapImageLayer.Item?.ItemId ?? "No Item ID";
                }
                else if (layer is Esri.ArcGISRuntime.Mapping.ArcGISTiledLayer tiledLayer)
                {
                    layerItem.Url = tiledLayer.Source?.ToString() ?? "No URL available";
                    layerItem.ItemId = tiledLayer.Item?.ItemId ?? "No Item ID";
                }
                else
                {
                    layerItem.Url = "Offline layer - no URL";
                    layerItem.ItemId = "Offline layer - no Item ID";
                }

                System.Diagnostics.Debug.WriteLine($"Layer metadata extracted for '{layerItem.Name}':");
                System.Diagnostics.Debug.WriteLine($"  Description: {layerItem.Description}");
                System.Diagnostics.Debug.WriteLine($"  Full Extent: {layerItem.FullExtent}");
                System.Diagnostics.Debug.WriteLine($"  Scale Range: {layerItem.MinScale} to {layerItem.MaxScale}");
                System.Diagnostics.Debug.WriteLine($"  URL: {layerItem.Url}");
                System.Diagnostics.Debug.WriteLine($"  Item ID: {layerItem.ItemId}");
                System.Diagnostics.Debug.WriteLine($"  Popup Title: {layerItem.PopupTitle}");
                System.Diagnostics.Debug.WriteLine($"  Popup Fields: {layerItem.PopupFields}");
                System.Diagnostics.Debug.WriteLine($"  Has Popup Definition: {layerItem.HasPopupDefinition}");
                System.Diagnostics.Debug.WriteLine("---");
            }
            catch (Exception)
            {
                System.Diagnostics.Debug.WriteLine($"Error extracting metadata for layer '{layer.Name}'");
                layerItem.Description = "Error extracting metadata";
            }

            return layerItem;
        }

        private void ExtractPopupDefinition(Layer layer, LayerItem layerItem)
        {
            try
            {
                // In ArcGIS Runtime 200.8, PopupDefinition is not directly accessible on all layer types
                // For now, we'll indicate that popup functionality would need to be implemented
                // using IdentifyLayerAsync when the user clicks on features
                
                layerItem.HasPopupDefinition = false;
                layerItem.PopupTitle = "Popup data available on click";
                layerItem.PopupFields = "Use IdentifyLayerAsync to get feature attributes";
                
                System.Diagnostics.Debug.WriteLine($"  Layer '{layer.Name}' - Popup data can be retrieved using IdentifyLayerAsync on user click");
                System.Diagnostics.Debug.WriteLine($"  This would show feature attributes and field information when user clicks on features");
            }
            catch (Exception)
            {
                System.Diagnostics.Debug.WriteLine($"Error extracting popup definition for layer '{layer.Name}'");
                layerItem.HasPopupDefinition = false;
                layerItem.PopupTitle = "Error extracting popup info";
                layerItem.PopupFields = "Error extracting popup fields";
            }
        }

        private void ClosePopup()
        {
            IsPopupVisible = false;
            PopupTitle = "";
            PopupContent = "";
            PopupLayerName = "";
            PopupAssetId = "";
            PopupComments = "";
            PopupLocation = "";
            PopupStatus = "";
            PopupType = "";
            PopupLastUpdated = "";
            PopupRows.Clear();
        }

        private void CreateWorkOrder()
        {
            try
            {
                // Minimize the hosting modal popup window (instead of closing)
                try
                {
                    var currentWindow = System.Windows.Application.Current.Windows.OfType<Views.ModalPopupWindow>()
                        .FirstOrDefault(w => w.PopupContent is Views.NapervilleView);
                    if (currentWindow != null)
                    {
                        currentWindow.WindowState = System.Windows.WindowState.Minimized;
                    }
                }
                catch { }

                // Navigate main app to Web page
                if (System.Windows.Application.Current.MainWindow?.DataContext is MainViewModel mainVM)
                {
                    // Ensure WebView has an address
                    if (mainVM.WebViewModel != null && string.IsNullOrWhiteSpace(mainVM.WebViewModel.BrowserAddress))
                    {
                        mainVM.WebViewModel.BrowserAddress = "http://localhost:4200/";
                    }

                    mainVM.NavigateToWebCommand.Execute(null);

                    // After navigation, ask Angular to switch to Create Work Order page
                    // Send a command payload the web app listens for
                    // Build fields collection from current popup rows
                    var fields = new System.Collections.Generic.List<object>();
                    foreach (var r in PopupRows)
                    {
                        fields.Add(new { label = r.Label, value = r.Value });
                    }

                    var payload = new { command = "switchToCreateWorkOrder", context = new { title = PopupTitle, data = SelectedFeatureData, fields } };
                    var json = System.Text.Json.JsonSerializer.Serialize(payload);
                    mainVM.SendMessageToAngularViaWebView(json);

                    System.Diagnostics.Debug.WriteLine("Sent navigate command to Angular: " + json);
                }

                // Also clear/close the in-view popup content if showing
                ClosePopup();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error creating work order: {ex.Message}");
                System.Windows.MessageBox.Show(
                    $"Error creating work order: {ex.Message}",
                    "Error",
                    System.Windows.MessageBoxButton.OK,
                    System.Windows.MessageBoxImage.Error);
            }
        }


        public async Task HandleMapClick(Esri.ArcGISRuntime.UI.Controls.MapView mapView, Esri.ArcGISRuntime.UI.Controls.GeoViewInputEventArgs e)
        {
            try
            {
                // Close any existing popup
                ClosePopup();

                // Set up identify parameters
                double tolerance = 10; // pixels
                bool returnPopupsOnly = false;
                int maxResults = 10;

                // Identify features at the clicked location
                var identifyResult = await mapView.IdentifyLayersAsync(e.Position, tolerance, returnPopupsOnly, maxResults);

                if (identifyResult != null && identifyResult.Count > 0)
                {
                    // Find the first layer with results
                    foreach (var layerResult in identifyResult)
                    {
                        if (layerResult.GeoElements != null && layerResult.GeoElements.Count > 0)
                        {
                            // Get the layer name
                            var layerName = layerResult.LayerContent?.Name ?? "Unknown Layer";
                            
                            // Get the first feature
                            var feature = layerResult.GeoElements[0];
                            
                            // Extract attributes
                            var attributes = feature.Attributes;
                            
                            if (attributes != null && attributes.Count > 0)
                            {
                                // Get Object ID from attributes
                                var objectId = "Unknown";
                                if (attributes.ContainsKey("OBJECTID"))
                                {
                                    objectId = attributes["OBJECTID"]?.ToString() ?? "Unknown";
                                }
                                else if (attributes.ContainsKey("ObjectId"))
                                {
                                    objectId = attributes["ObjectId"]?.ToString() ?? "Unknown";
                                }
                                else if (attributes.ContainsKey("FID"))
                                {
                                    objectId = attributes["FID"]?.ToString() ?? "Unknown";
                                }

                                // Build popup content
                                var popupContent = new System.Text.StringBuilder();
                                popupContent.AppendLine($"Feature Type: {feature.Geometry?.GeometryType}");
                                popupContent.AppendLine("");
                                popupContent.AppendLine("Attributes:");
                                
                                foreach (var attribute in attributes)
                                {
                                    var value = attribute.Value?.ToString() ?? "null";
                                    popupContent.AppendLine($"  {attribute.Key}: {value}");
                                }

                                // Helper to fetch first non-empty attribute by possible keys
                                string GetAttr(params string[] keys)
                                {
                                    foreach (var key in keys)
                                    {
                                        if (attributes.ContainsKey(key))
                                        {
                                            var v = attributes[key]?.ToString();
                                            if (!string.IsNullOrWhiteSpace(v)) return v!;
                                        }
                                    }
                                    return "-";
                                }

                                // Populate strongly-typed fields (best-effort mappings)
                                PopupAssetId = GetAttr("AssetId", "ASSETID", "Asset ID", "ASSET_ID", "FACILITYID", "FACILITY_ID", "OBJECTID", "ObjectId", "FID");
                                PopupComments = GetAttr("Comments", "COMMENTS", "Comment");
                                PopupLocation = GetAttr("Location", "LOCATION", "LocationDescription_OPS", "LOC_DESC", "ADDR", "Address");
                                PopupStatus = GetAttr("Status", "STATUS", "STATE");
                                PopupType = GetAttr("Type", "TYPE", "AssetType", "ASSETTYPE");
                                PopupLastUpdated = GetAttr("LastUpdated", "LASTUPDATED", "Last_Edit_Date", "EditDate", "LastUpdate");

                                // Build display rows from PopupDefinition if available, else from attributes
                                PopupRows.Clear();
                                bool populatedFromPopupDef = false;
                                try
                                {
                                    if (layerResult.LayerContent is Esri.ArcGISRuntime.Mapping.FeatureLayer featureLayer && featureLayer.PopupDefinition != null)
                                    {
                                        var pd = featureLayer.PopupDefinition;
                                        if (pd.Fields != null && pd.Fields.Count > 0)
                                        {
                                            foreach (var pf in pd.Fields)
                                            {
                                                var fieldName = pf.FieldName;
                                                var label = string.IsNullOrWhiteSpace(pf.Label) ? fieldName : pf.Label;
                                                string val = attributes.ContainsKey(fieldName) ? attributes[fieldName]?.ToString() ?? "-" : "-";
                                                PopupRows.Add(new FieldRow { Label = label, Value = val });
                                            }
                                            populatedFromPopupDef = PopupRows.Count > 0;
                                        }
                                    }
                                }
                                catch { /* ignore - fallback below */ }

                                // Only show actual fields from PopupDefinition. If not available, show nothing.
                                if (!populatedFromPopupDef)
                                {
                                    PopupRows.Clear();
                                }

                                // Position near click with clamping to visible area of the MapView
                                double desiredX = e.Position.X + 10; // right of click
                                double desiredY = e.Position.Y - 10; // above click

                                // Try to get the map view size to clamp within bounds
                                var mapViewRef = mapView;
                                double viewWidth = mapViewRef?.ActualWidth ?? 0;
                                double viewHeight = mapViewRef?.ActualHeight ?? 0;

                                // Estimated popup size bounds (match XAML MaxWidth/MaxHeight)
                                double popupWidth = 450; // MaxWidth
                                double popupHeight = 480; // MaxHeight

                                // Clamp horizontally
                                if (viewWidth > 0)
                                {
                                    if (desiredX + popupWidth > viewWidth) desiredX = Math.Max(0, viewWidth - popupWidth - 10);
                                }

                                // Clamp vertically (ensure fully visible)
                                if (viewHeight > 0)
                                {
                                    if (desiredY + popupHeight > viewHeight) desiredY = Math.Max(0, viewHeight - popupHeight - 10);
                                    if (desiredY < 0) desiredY = 10;
                                }

                                PopupX = desiredX;
                                PopupY = desiredY;

                                // Show popup with Layer Name + Object ID as title
                                PopupTitle = $"{layerName} - ID: {objectId}";
                                PopupContent = popupContent.ToString();
                                PopupLayerName = layerName;
                                IsPopupVisible = true;

                                System.Diagnostics.Debug.WriteLine($"Feature clicked in layer '{layerName}' with Object ID '{objectId}':");
                                System.Diagnostics.Debug.WriteLine(popupContent.ToString());
                                
                                return; // Show only the first result
                            }
                        }
                    }
                }

                // If no features found, don't show popup
                System.Diagnostics.Debug.WriteLine("No features found at clicked location");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error handling map click: {ex.Message}");
                // Don't show popup on error either
            }
        }

        private void LogLayerSummary()
        {
            System.Diagnostics.Debug.WriteLine("=== LAYER SUMMARY ===");
            System.Diagnostics.Debug.WriteLine($"Total Layers: {Layers.Count}");
            System.Diagnostics.Debug.WriteLine("");
            
            for (int i = 0; i < Layers.Count; i++)
            {
                var layer = Layers[i];
                System.Diagnostics.Debug.WriteLine($"{i + 1}. {layer.Name}");
                System.Diagnostics.Debug.WriteLine($"   Type: {layer.LayerType}");
                System.Diagnostics.Debug.WriteLine($"   Description: {layer.Description}");
                System.Diagnostics.Debug.WriteLine($"   Is Visible: {layer.IsVisible}");
                System.Diagnostics.Debug.WriteLine($"   Layer.IsVisible: {layer.Layer?.IsVisible}");
                System.Diagnostics.Debug.WriteLine($"   Has Popup: {layer.HasPopupDefinition}");
                System.Diagnostics.Debug.WriteLine($"   Popup Title: {layer.PopupTitle}");
                System.Diagnostics.Debug.WriteLine($"   Popup Fields: {layer.PopupFields}");
                System.Diagnostics.Debug.WriteLine("");
            }
            
            // Check for services layer specifically
            var servicesLayer = Layers.FirstOrDefault(l => l.Name.ToLower().Contains("service"));
            if (servicesLayer != null)
            {
                System.Diagnostics.Debug.WriteLine("=== SERVICES LAYER FOUND ===");
                System.Diagnostics.Debug.WriteLine($"Name: {servicesLayer.Name}");
                System.Diagnostics.Debug.WriteLine($"Is Visible: {servicesLayer.IsVisible}");
                System.Diagnostics.Debug.WriteLine($"Layer.IsVisible: {servicesLayer.Layer?.IsVisible}");
                System.Diagnostics.Debug.WriteLine("=== END SERVICES LAYER ===");
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("=== NO SERVICES LAYER FOUND ===");
                System.Diagnostics.Debug.WriteLine("Layers containing 'service' in name:");
                foreach (var layer in Layers.Where(l => l.Name.ToLower().Contains("service")))
                {
                    System.Diagnostics.Debug.WriteLine($"  - {layer.Name}");
                }
            }
            
            System.Diagnostics.Debug.WriteLine("=== END LAYER SUMMARY ===");
        }

        private string GetLayerTypeName(Layer layer)
        {
            return layer switch
            {
                Esri.ArcGISRuntime.Mapping.ArcGISMapImageLayer => "Map Image Layer",
                Esri.ArcGISRuntime.Mapping.ArcGISTiledLayer => "Tiled Layer",
                Esri.ArcGISRuntime.Mapping.ArcGISVectorTiledLayer => "Vector Tiled Layer",
                _ => layer.GetType().Name
            };
        }

        private string GetLayerInformation(Map map)
        {
            try
            {
                var layerInfo = new System.Text.StringBuilder();
                
                // Check basemap layers
                if (map.Basemap?.BaseLayers != null)
                {
                    layerInfo.AppendLine($"Basemap Layers: {map.Basemap.BaseLayers.Count}");
                    for (int i = 0; i < map.Basemap.BaseLayers.Count; i++)
                    {
                        var layer = map.Basemap.BaseLayers[i];
                        layerInfo.AppendLine($"  - {layer.Name ?? $"Basemap Layer {i + 1}"}");
                    }
                }
                
                // Check operational layers
                if (map.OperationalLayers != null)
                {
                    layerInfo.AppendLine($"Operational Layers: {map.OperationalLayers.Count}");
                    for (int i = 0; i < map.OperationalLayers.Count; i++)
                    {
                        var layer = map.OperationalLayers[i];
                        layerInfo.AppendLine($"  - {layer.Name ?? $"Operational Layer {i + 1}"}");
                    }
                }
                
                // Check reference layers
                if (map.Basemap?.ReferenceLayers != null)
                {
                    layerInfo.AppendLine($"Reference Layers: {map.Basemap.ReferenceLayers.Count}");
                    for (int i = 0; i < map.Basemap.ReferenceLayers.Count; i++)
                    {
                        var layer = map.Basemap.ReferenceLayers[i];
                        layerInfo.AppendLine($"  - {layer.Name ?? $"Reference Layer {i + 1}"}");
                    }
                }
                
                return layerInfo.ToString().Trim();
            }
            catch (Exception ex)
            {
                return $"Error getting layer information: {ex.Message}";
            }
        }
    }
}
