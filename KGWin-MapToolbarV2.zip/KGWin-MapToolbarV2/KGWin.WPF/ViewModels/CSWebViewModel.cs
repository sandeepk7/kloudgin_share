using KGWin.WPF.ViewModels.Base;
using Microsoft.Extensions.Configuration;

namespace KGWin.WPF.ViewModels
{
    public class CSWebViewModel : ViewModelBase
    {
        public CSWebViewModel(IConfiguration? configuration = null)
        {
            // Initialize browser address from configuration or use default
            var configuredAddress = configuration?["Browser:Address"];
            _browserAddress = !string.IsNullOrEmpty(configuredAddress) ? configuredAddress : "http://localhost:4200";
        }

        private string _browserAddress;
        public string BrowserAddress 
        { 
            get => _browserAddress; 
            set => SetProperty(ref _browserAddress, value); 
        }
    }
}
