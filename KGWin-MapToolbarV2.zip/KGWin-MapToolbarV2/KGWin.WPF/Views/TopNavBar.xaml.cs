using System.Windows.Controls;

namespace KGWin.WPF.Views
{
    public partial class TopNavBar : UserControl
    {
        public TopNavBar()
        {
            InitializeComponent();
        }
    }
}


