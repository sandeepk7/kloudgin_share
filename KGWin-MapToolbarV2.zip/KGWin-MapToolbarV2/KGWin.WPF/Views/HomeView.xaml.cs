using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for HomeView.xaml
    /// </summary>
    public partial class HomeView : UserControl
    {
        public HomeView()
        {
            InitializeComponent();
        }

        private void InteractiveTextItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is FrameworkElement element && element.DataContext is InteractiveTextItem item)
            {
                item.ToggleSelectionCommand.Execute(null);
                e.Handled = true;
            }
        }
    }
}

