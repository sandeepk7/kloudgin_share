using System.Windows;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for WebMapPopupView.xaml
    /// </summary>
    public partial class WebMapPopupView : Window
    {
        public WebMapPopupView()
        {
            InitializeComponent();
        }

        public WebMapPopupView(string webMapUrl) : this()
        {
            // Set the DataContext with the URL
            DataContext = new { WebMapUrl = webMapUrl };
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
