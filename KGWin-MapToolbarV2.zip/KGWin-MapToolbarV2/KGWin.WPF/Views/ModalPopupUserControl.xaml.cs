using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using KGWin.WPF.ViewModels;

namespace KGWin.WPF.Views
{
    public partial class ModalPopupUserControl : UserControl
    {
        private ModalPopupViewModel? _viewModel;

        public ModalPopupUserControl()
        {
            InitializeComponent();
            this.DataContextChanged += ModalPopupUserControl_DataContextChanged;
        }

        private void ModalPopupUserControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue is ModalPopupViewModel vm)
            {
                _viewModel = vm;
            }
        }

        public ModalPopupUserControl(ModalPopupViewModel viewModel) : this()
        {
            _viewModel = viewModel;
            DataContext = _viewModel;
        }

        public ModalPopupUserControl(string title, object content, ModalPopupConfig? config = null) : this()
        {
            _viewModel = new ModalPopupViewModel(title, content, config);
            DataContext = _viewModel;
        }

        public void Show()
        {
            // Ensure we have the view model reference
            if (_viewModel == null && this.DataContext is ModalPopupViewModel vm)
            {
                _viewModel = vm;
            }
            
            this.Visibility = Visibility.Visible;
            this.Focus();
        }

        public void Hide()
        {
            this.Visibility = Visibility.Collapsed;
        }

        public new bool IsVisible => this.Visibility == Visibility.Visible;

        private void Backdrop_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Debug.WriteLine($"Backdrop clicked. ViewModel: {_viewModel != null}, CloseOnBackdropClick: {_viewModel?.CloseOnBackdropClick}");
            
            if (_viewModel?.CloseOnBackdropClick == true)
            {
                System.Diagnostics.Debug.WriteLine("Closing modal due to backdrop click");
                Hide();
            }
        }

        private void PopupContainer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Prevent the click from bubbling to the backdrop
            e.Handled = true;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Hide();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            _viewModel?.OnCancel?.Invoke();
            Hide();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            _viewModel?.OnOk?.Invoke();
            Hide();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Escape && _viewModel?.CloseOnEscape == true)
            {
                Hide();
            }
            base.OnKeyDown(e);
        }
    }
}
