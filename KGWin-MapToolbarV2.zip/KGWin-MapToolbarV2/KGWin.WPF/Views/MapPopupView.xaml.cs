using System.Windows.Controls;

namespace KGWin.WPF.Views
{
    /// <summary>
    /// Interaction logic for MapPopupView.xaml
    /// </summary>
    public partial class MapPopupView : UserControl
    {
        public MapPopupView()
        {
            InitializeComponent();
        }
    }
}






