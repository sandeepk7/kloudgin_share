using System.Windows.Controls;
using System.Windows.Input;
using System.Windows;

namespace KGWin.WPF.Views
{
    public partial class CommunicationView : UserControl
    {
        public CommunicationView()
        {
            InitializeComponent();
            
            // Subscribe to chat messages collection changes to auto-scroll
            if (DataContext is ViewModels.CommunicationViewModel viewModel)
            {
                viewModel.ChatMessages.CollectionChanged += (sender, e) =>
                {
                    // Auto-scroll to bottom when new messages are added
                    ChatScrollViewer.ScrollToBottom();
                };
            }
        }

        private void MessageTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
            {
                e.Handled = true;
                
                if (DataContext is ViewModels.CommunicationViewModel viewModel)
                {
                    viewModel.SendMessageCommand.Execute(null);
                }
            }
        }
    }
}
