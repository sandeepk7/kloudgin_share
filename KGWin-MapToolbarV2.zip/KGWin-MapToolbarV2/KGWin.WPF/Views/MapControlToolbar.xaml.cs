using System.Windows.Controls;

namespace KGWin.WPF.Views
{
    public partial class MapControlToolbar : UserControl
    {
        public MapControlToolbar()
        {
            InitializeComponent();
        }
    }
}


